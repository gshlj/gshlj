function [J grad] = nnCostFunction(nn_params, layer_sizes, X, y, lambda)
%NNCOSTFUNCTION Implements the neural network cost function for a two layer
%neural network which performs classification
%   [J grad] = NNCOSTFUNCTON(nn_params, hidden_layer_size, num_labels, ...
%   X, y, lambda) computes the cost and gradient of the neural network. The
%   parameters for the neural network are "unrolled" into the vector
%   nn_params and need to be converted back into the weight matrices. 
% 
%   The returned parameter grad should be a "unrolled" vector of the
%   partial derivatives of the neural network.
%

% Reshape nn_params back into the parameters Theta1 and Theta2, the weight matrices
% for our 2 layer neural network

layer_num=size(layer_sizes,2);
if layer_num<2
  error('wrong layer_sizes');
end
num_labels=layer_sizes(layer_num);

Theta={};
Theta_grad={};
theta_=[];

idx_start=1;
for i=1:layer_num-1
  size_before=(layer_sizes(1,i) + 1);
  size_after=layer_sizes(1,i+1);
  idx_end=size_after * size_before + idx_start -1;
  Theta_i=reshape(nn_params(idx_start:idx_end),size_after,size_before);
  Theta{i}=Theta_i;
  Theta_grad{i} = zeros(size(Theta_i));
  idx_start=idx_end+1;
  tmp=Theta_i(:,2:end);
  theta_=[theta_;tmp(:)];
end

%Theta1 = reshape(nn_params(1:hidden_layer_size * (input_layer_size + 1)), ...
%                 hidden_layer_size, (input_layer_size + 1));

%Theta2 = reshape(nn_params((1 + (hidden_layer_size * (input_layer_size + 1))):end), ...
%                 num_labels, (hidden_layer_size + 1));

% Setup some useful variables
m = size(X, 1);
         
% You need to return the following variables correctly 
J = 0;
%Theta1_grad = zeros(size(Theta1));
%Theta2_grad = zeros(size(Theta2));

% ====================== YOUR CODE HERE ======================

Y=zeros(m,num_labels);
for i=1:m
  Y(i,y(i))=1;
end

%A2=fowardPropagation(X,Theta1);
%OUT=fowardPropagation(A2,Theta2);

A={};
A{1}=X;
for i=2:layer_num
  A{i}=fowardPropagation(A{i-1},Theta{i-1});
end
OUT=A{layer_num};

J= sum(sum(-Y.*log(OUT)-(1-Y).*log(1-OUT),2),1)/m;
%not only 1 zero in theta1,2...
%tmp1=Theta1(:,2:end);
%tmp2=Theta2(:,2:end);
%thetaX0 = [tmp1(:);tmp2(:)];
regular=lambda/2/m*sum(theta_.^2);
J=J+regular;

%delta_3=OUT-Y;
%Ai0 = ones
%delta_2=delta_3*Theta2(:,2:end).*A2.*(1-A2);

%Theta1_grad=1/m*delta_2'*[ones(m,1),X]+ (lambda/m)*[zeros(size(Theta1,1), 1) Theta1(:, 2:end)];
%Theta2_grad=1/m*delta_3'*[ones(m,1),A2]+ (lambda/m)*[zeros(size(Theta2,1), 1) Theta2(:, 2:end)];
%Theta2_grad

D={};
D{layer_num}=OUT-Y;
for i=layer_num-1:-1:1
  D_i=D{i+1}*Theta{i}(:,2:end).*A{i}.*(1-A{i});
  D{i}=D_i;
  Theta_grad{i}=1/m*D{i+1}'*[ones(m,1),A{i}]+ (lambda/m)*[zeros(size(Theta{i},1), 1) Theta{i}(:, 2:end)];
end

% -------------------------------------------------------------

% =========================================================================

% Unroll gradients
%grad = [Theta1_grad(:) ; Theta2_grad(:)];
grad=[];
for i=1:layer_num-1
  grad=[grad;Theta_grad{i}(:)];
end

end
