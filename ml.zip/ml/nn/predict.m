function [p,dummy] = predict(nn_params, layer_sizes, X)
%PREDICT Predict the label of an input given a trained neural network
%   p = PREDICT(Theta1, Theta2, X) outputs the predicted label of X given the
%   trained weights of a neural network (Theta1, Theta2)

% Useful values
m = size(X, 1);
%num_labels = size(Theta2, 1);

% You need to return the following variables correctly 
p = zeros(size(X, 1), 1);

%h1 = sigmoid([ones(m, 1) X] * Theta1');
%h2 = sigmoid([ones(m, 1) h1] * Theta2');
%[dummy, p] = max(h2, [], 2);

layer_num=size(layer_sizes,2);
num_labels=layer_sizes(layer_num);
Theta={};
idx_start=1;
for i=1:layer_num-1
  size_before=(layer_sizes(1,i) + 1);
  size_after=layer_sizes(1,i+1);
  idx_end=size_after * size_before + idx_start -1;
  Theta_i=reshape(nn_params(idx_start:idx_end),size_after,size_before);
  Theta{i}=Theta_i;
  idx_start=idx_end+1;
end
A={};
A{1}=X;
for i=2:layer_num
  A{i}=fowardPropagation(A{i-1},Theta{i-1});
end
OUT=A{layer_num};
[dummy, p] = max(OUT, [], 2);
% =========================================================================


end
