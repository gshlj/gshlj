function a = fowardPropagation(X,Theta)
  m=size(X,1);
  a=sigmoid([ones(m,1) X]*Theta');
end
