addpath('./common');
addpath('./nn');
clear ; close all; clc
 
%data=importdata('data_ex4.txt');
%X=data(:,1:400);
%y=data(:,401);
%ho_l_sizes=[25,10];
 
m=20000;%23000
X=rand(m,100)*2-1;
X_x=rand(m,10)*2-1;
y0=(X(:,1).*X(:,2)./X(:,4)-X(:,3))*100;

sort=sort(y0);
y_mid=sort(m/2);

y=ones(m,1);
y(find(y0>y_mid))=2;
layer_sizes=[20,20,2];

save('test','X','y');
nnCall(0.8, layer_sizes,200);
%nnCall->nnFunction
 
%m=size(X,1);
%y=zeros(m,10);
%for i=1:m
%  y(i,Y(i))=1;
%end
