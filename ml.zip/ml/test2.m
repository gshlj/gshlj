addpath('./common');
addpath('./nn');
clear ; close all; clc
 
%data=importdata('data_ex4.txt');
%X=data(:,1:400);
%y=data(:,401);
%ho_l_sizes=[25,10];
 
m=20000;%23000
X=randn(m,100);
X_x=randn(m,1);
y_tmp=((log(10000+1000*X(:,6))+100*X(:,40)).*X(:,71+10).^2./(100-X(:,20))*30+X(:,11))*0.6+7*X_x;
 
y=ones(m,1);
y(find(y_tmp>0))=2;
ho_l_sizes=[20,20,2];
 
save('test','X','y');
nnCall(0.8, ho_l_sizes,0,300);
%nnCall->nnFunction
 
%m=size(X,1);
%y=zeros(m,10);
%for i=1:m
%  y(i,Y(i))=1;
%end
