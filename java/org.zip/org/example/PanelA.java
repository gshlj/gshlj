package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.List;
import java.util.Random;

public class PanelA extends JFrame {
    private JTextField symbolField, startField, lengthField, thresholdField;
    private JLabel maxMatch = new JLabel("maxMatch:");
    private JTable resultTable;
    private DefaultTableModel tableModel;

    public PanelA() {
        setTitle("Panel Example");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);

        // 创建面板
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        // 上部分
        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());

        symbolField = new JTextField(5);
        startField = new JTextField(5);
        lengthField = new JTextField(5);
        thresholdField = new JTextField(5);
        lengthField.setText("50");
        thresholdField.setText("93");

        JButton queryButton = new JButton("Query");
        JButton analyzeButton = new JButton("Analyze");

        topPanel.add(new JLabel("Symbol:"));
        topPanel.add(symbolField);
        topPanel.add(new JLabel("Start:"));
        topPanel.add(startField);
        topPanel.add(new JLabel("Length:"));
        topPanel.add(lengthField);
        topPanel.add(queryButton);
        topPanel.add(analyzeButton);

        topPanel.add(maxMatch);topPanel.add(thresholdField);

        // 下部分 - 使用表格显示数据
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Num");
        tableModel.addColumn("symbol");
        tableModel.addColumn("start");
        tableModel.addColumn("end");
        tableModel.addColumn("length");
        tableModel.addColumn("match");
        tableModel.addColumn("Action");

        resultTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(resultTable);

        // 添加到主面板
        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);


        // 添加按钮点击事件
        queryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //float [] f = Step02LoadData.data[Step02LoadData.symbolIdx.get(Float.parseFloat(symbolField.getText()))]
                //        [Step02LoadData.dateIdx.get(Float.parseFloat(startField.getText()))];
                int lentgh = Integer.parseInt(lengthField.getText());
                float [][] datak = new  float [lentgh][7];
                System.arraycopy(Step02LoadData.data[Step02LoadData.symbolIdx.get(Float.parseFloat(symbolField.getText()))],
                        Step02LoadData.dateIdx.get(Float.parseFloat(startField.getText())), datak, 0, lentgh);
                PanelK.drawK(datak);
                System.out.println(1);

            }
        });

        analyzeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int cnt = 0;
                float threshold = Float.parseFloat(thresholdField.getText());
                float max = -99f;
                float[][][] data = Step02LoadData.data;

                tableModel.getDataVector().clear();

                try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(Step01ReadBCP.dataDrawPath))) {
                    List<float[]> list = (List<float[]>) ois.readObject();
                    for(float[] seed:list){
                        int length = seed.length;
                        System.out.println("seed.length:"+length);
                        float[] tmp = new float[length];
                        for(int i = 0 ; i < data.length ; i++){
                            float[] close = new float[data[0].length];
                            for(int j = 0 ; j < data[0].length ; j++){
                                close[j] = data[i][j][2];
                            }
                            for(int j = 0 ; j+length-1 < close.length ; j++){
                                if(close[j] > 0 && close[j+length-1] > 0){
                                    System.arraycopy(close,j,tmp,0,length);
                                    float result = util.PxyFloat(seed,tmp);
                                    if(result>max){
                                        max=result;
                                    }
                                    if(result>threshold){
                                        addRowToTable(++cnt,data[i][j][0], data[i][j][1],
                                                data[i][j+length-1][1],length,result);
                                    }
                                }
                            }
                        }
                    }
                    maxMatch.setText(""+max);


                } catch (Exception e2) {
                    e2.printStackTrace();
                }
            }
        });

        // 设置行按钮的点击事件
        addRowButtonAction();

        // 将面板添加到窗口
        add(panel);

        // 设置窗口可见
        setVisible(true);
    }

    private void addRowToTable(int num, float a, float b, float c, float d, float e) {
        Object[] rowData = {num, a, b, c, d, e, "Query"};
        tableModel.addRow(rowData);
    }

    private void addRowButtonAction() {
        JButton rowButton = new JButton("Query");
        rowButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = resultTable.getSelectedRow();
                if (selectedRow != -1) {
                    int num = (int) resultTable.getValueAt(selectedRow, 0);
                    System.out.println("Clicked on row with Num: " + num);

                    float symbol = (float) resultTable.getValueAt(selectedRow, 1);
                    float sdate = (float) resultTable.getValueAt(selectedRow, 2);
                    int lentgh = Math.round( (float)resultTable.getValueAt(selectedRow, 4));
                    int dateIdx = Step02LoadData.dateIdx.get(sdate);
                    int extend = 10;

                    int cplength = lentgh+extend+dateIdx<Step02LoadData.data[0].length? lentgh+extend: Step02LoadData.data[0].length-1-(lentgh+extend+dateIdx);

                    float [][] datak = new  float [cplength][7];
                    System.arraycopy(Step02LoadData.data[Step02LoadData.symbolIdx.get(symbol)],dateIdx,
                            datak, 0, cplength);
                    PanelK.drawK(datak);
                    System.out.println(1);
                }
            }
        });

        TableColumn column = resultTable.getColumnModel().getColumn(6);
        column.setCellRenderer(new ButtonRenderer());
        column.setCellEditor(new ButtonEditor(rowButton));
    }

    private class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    private class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private String label;
        private boolean isPushed;

        public ButtonEditor(JButton button) {
            super(new JCheckBox());
            this.button = button;
            this.button.setOpaque(true);
            this.button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    fireEditingStopped();
                }
            });
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            if (isSelected) {
                button.setForeground(table.getSelectionForeground());
                button.setBackground(table.getSelectionBackground());
            } else {
                button.setForeground(table.getForeground());
                button.setBackground(UIManager.getColor("Button.background"));
            }

            label = (value == null) ? "" : value.toString();
            button.setText(label);
            isPushed = true;
            return button;
        }

        @Override
        public Object getCellEditorValue() {
            /*if (isPushed) {
                // Button clicked
                int selectedRow = resultTable.getSelectedRow();
                if (selectedRow != -1) {
                    int num = (int) resultTable.getValueAt(selectedRow, 0);
                    System.out.println("Clicked on row with Num: " + num);
                }
            }
            isPushed = false;*/
            return label;
        }

        @Override
        public boolean stopCellEditing() {
            isPushed = false;
            return super.stopCellEditing();
        }

        @Override
        protected void fireEditingStopped() {
            super.fireEditingStopped();
        }
    }

    public static void main(String[] args) {
        Step02LoadData.main(null);
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new PanelA();
            }
        });
    }
}
