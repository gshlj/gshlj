package org.example;

import javax.swing.*;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;
import java.awt.*;
import javax.swing.text.AbstractDocument;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class PanelDrawing extends JFrame {
    private List<Point> points = new ArrayList<>();
    private boolean drawing = false;

    private int lastX = -1;

    private JTextField textField1;
    private JTextField textField2;


    static class NumericFilter extends DocumentFilter {
        @Override
        public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr) throws BadLocationException {
            if (string.matches("\\d*")) {
                super.insertString(fb, offset, string, attr);
            }
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs) throws BadLocationException {
            if (text.matches("\\d*")) {
                super.replace(fb, offset, length, text, attrs);
            }
        }
    }

    public static List<Point> interpolatePoints(List<Point> originalPoints) {
        List<Point> interpolatedPoints = new ArrayList<>();

        for (int i = 0; i < originalPoints.size() - 1; i++) {
            Point currentPoint = originalPoints.get(i);
            Point nextPoint = originalPoints.get(i + 1);

            interpolatedPoints.add(currentPoint);

            int xDiff = nextPoint.x - currentPoint.x;

            if (xDiff > 1) {
                // If x coordinates are not consecutive, insert missing points
                for (int j = 1; j < xDiff; j++) {
                    int interpolatedX = currentPoint.x + j;
                    int interpolatedY = (currentPoint.y + nextPoint.y) / 2;
                    interpolatedPoints.add(new Point(interpolatedX, interpolatedY));
                }
            }
        }

        // Add the last point
        interpolatedPoints.add(originalPoints.get(originalPoints.size() - 1));

        return interpolatedPoints;
    }

    public static List<Point> transformCoordinates(List<Point> originalPoints) {
        List<Point> transformedPoints = new ArrayList<>();

        int minX = Integer.MAX_VALUE;
        int maxY = Integer.MIN_VALUE;

        // Find the minimum x and maximum y in the original points
        for (Point point : originalPoints) {
            minX = Math.min(minX, point.x);
            maxY = Math.max(maxY, point.y);
        }

        // Transform coordinates
        for (Point point : originalPoints) {
            int transformedX = point.x - minX;
            int transformedY = Math.abs(point.y - maxY);

            transformedPoints.add(new Point(transformedX, transformedY));
        }

        return transformedPoints;
    }

    public static float[] generateNewArray(int a, float[] originalArray) {
        int originalLength = originalArray.length;

        if (a <= 0) {
            throw new IllegalArgumentException("Invalid value of a. It must be greater than 0.");
        }

        float[] newArray = new float[a];
        float interval = (float)(originalLength - 1) / (a - 1);

        for (int i = 0; i < a; i++) {
            int index = Math.min(Math.round(i * interval), originalLength - 1);
            newArray[i] = originalArray[index];
        }
        System.out.println(Arrays.toString(newArray));
        return newArray;
    }

    public PanelDrawing() {
        setTitle("Drawing Panel");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();
        JButton clearButton = new JButton("Clear");
        JButton outputButton = new JButton("Output Points");

        textField1 = new JTextField(5);
        textField2 = new JTextField(5);

        ((AbstractDocument) textField1.getDocument()).setDocumentFilter(new NumericFilter());
        ((AbstractDocument) textField2.getDocument()).setDocumentFilter(new NumericFilter());

        JPanel textFieldPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        textFieldPanel.add(new JLabel("days1: "));
        textFieldPanel.add(textField1);
        textFieldPanel.add(new JLabel("days2: "));
        textFieldPanel.add(textField2);

        getContentPane().add(textFieldPanel, BorderLayout.NORTH);
        getContentPane().add(panel, BorderLayout.NORTH);


        panel.add(clearButton);
        panel.add(outputButton);
        panel.add(textFieldPanel);

        DrawingCanvas canvas = new DrawingCanvas(points);
        canvas.setBackground(Color.white);

        getContentPane().add(canvas, BorderLayout.CENTER);

        clearButton.addActionListener(e -> {
            lastX = -1;
            points.clear();
            canvas.repaint();
        });

        outputButton.addActionListener(e -> {
            if (!points.isEmpty()) {

                List<Point> newPoints= transformCoordinates(interpolatePoints(points));
                float[] org =  new float[newPoints.size()];
                for (Point point : newPoints) {
                    org[point.x] = point.y;
                }

                int numeric1 = Integer.parseInt(textField1.getText());
                int numeric2 = Integer.parseInt(textField2.getText());

                List<float[]> list = new LinkedList<float[]>();

                for(int i = numeric1 ; i <=numeric2 ; i++ ){
                    list.add(generateNewArray(i,org));
                }
                try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(Step01ReadBCP.dataDrawPath))) {
                    oos.writeObject(list);
                } catch (IOException e1) {
                    e1.printStackTrace();
                }

            } else {
                System.out.println("No points to output.");
            }
        });

        canvas.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                if(lastX<e.getPoint().x){
                    lastX = e.getPoint().x;
                    drawing = true;
                    points.clear();
                    points.add(e.getPoint());
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                if(lastX<e.getPoint().x){
                    lastX = e.getPoint().x;
                    drawing = false;
                    canvas.repaint();
                }
            }
        });

        canvas.addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseDragged(MouseEvent e) {
                if (drawing && lastX<e.getPoint().x) {
                    lastX = e.getPoint().x;
                    points.add(e.getPoint());
                    canvas.repaint();
                }
            }
        });


    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            PanelDrawing drawingPanel = new PanelDrawing();
            drawingPanel.setVisible(true);
        });
    }
}

class DrawingCanvas extends JPanel {
    private List<Point> points;

    public DrawingCanvas(List<Point> points) {
        this.points = points;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!points.isEmpty()) {
            drawCurve(g);
        }
    }

    private void drawCurve(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setColor(Color.black);
        g2d.setStroke(new BasicStroke(2));

        Point p1 = points.get(0);
        for (int i = 1; i < points.size(); i++) {
            Point p2 = points.get(i);
            g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
            p1 = p2;
        }
    }



}