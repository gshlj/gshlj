package org.example;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Step01ReadBCP {

    static String filePath= "D:\\gs\\Desktop\\STOCK\\old\\tbl_stk_pd1";
    static String dataPath= "D:\\gs\\Desktop\\data";
    static String data2Path= "D:\\gs\\Desktop\\data2";

    static String dataDrawPath= "D:\\gs\\Desktop\\tmp\\dataDraw";
    static private String separetor = "\t";
    static String dateFormatStr = "yyyy-MM-dd";// "MMM d yyyy"

    static Map<Float,Integer> symbolIdx = new HashMap<Float,Integer>();
    static Map<Float,Integer> dateIdx = new HashMap<Float,Integer>();
    static Float[] dates;

    static int len1st = 4000,len2nd=5000;

    static float[][][] data = new float[len1st][len2nd][7];

    public static void main(String[] args) {

        try {
            java.io.File file = new java.io.File(filePath);
            LineIterator iterator = FileUtils.lineIterator(file, "UTF-8");

            String lastSymbl = "";
            int idxs = -1;
            int idxd = 0;
            Set<Float> days = new HashSet<Float>();
            while (iterator.hasNext()) {
                String inputText = iterator.nextLine();
                String[] tokens = inputText.split(separetor);
                String nowSymbl = tokens[0];
                if(!nowSymbl.equals(lastSymbl)){
                    lastSymbl=nowSymbl;
                    idxs++;
                    idxd = 0;
                    symbolIdx.put(Float.parseFloat(nowSymbl),idxs);
                }
                data[idxs][idxd][0] = Float.parseFloat(nowSymbl);
                float dt = convertDateStringToFloat(tokens[1]);
                data[idxs][idxd][1] = dt;
                days.add(dt);
                data[idxs][idxd][2] = Float.parseFloat(tokens[2]);
                data[idxs][idxd][3] = Float.parseFloat(tokens[3]);
                data[idxs][idxd][4] = Float.parseFloat(tokens[4]);
                data[idxs][idxd][5] = Float.parseFloat(tokens[5]);
                data[idxs][idxd][6] = Float.parseFloat(tokens[6]);
                idxd++;
            }

            Float[] floatDates = days.toArray(new Float[0]);
            Arrays.sort(floatDates, new Step01ReadBCP.CustomDateComparator());
            dates = floatDates;
            for(int i = 0 ; i < floatDates.length ; i ++ ){
                dateIdx.put(floatDates[i],i);
            }
            rearrangeDataByDateIdx();

            writeArrayToFile();
            writeData2ToFile();
            //System.out.println(1);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private static void rearrangeDataByDateIdx() {
        for (int i = 0; i < symbolIdx.size(); i++) {
            for (int j = 0; j< dateIdx.size() ; j++){
                float date = data[i][j][1];
                if(date == 0)
                    break;
                Integer newIndex = dateIdx.get(date);
                if(j != newIndex){
                    int off = newIndex-j;
                    System.out.println("symbol,date,off:"+data[i][j][0]+","+data[i][j][1]+","+off);
                    int remainingLength = len2nd - j;
                    float [][] newArray = new float[len2nd][7];
                    System.arraycopy(data[i], j, newArray, j+off, remainingLength-off);
                    System.arraycopy(data[i], 0, newArray, 0, j);
                    data[i] = newArray;
                    j=newIndex;
                }
            }
        }
    }

    public static void writeArrayToFile() {
        try (RandomAccessFile file = new RandomAccessFile(dataPath, "rw");
             FileChannel channel = file.getChannel()) {

            int numRows = symbolIdx.size();
            int numCols = dateIdx.size();
            int dataSize = numRows * numCols * 7 * Float.BYTES;

            MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_WRITE, 0, dataSize);

            for (int i = 0; i < numRows; i++) {
                for (int j = 0; j < numCols; j++) {
                    for (int k = 0; k < 7; k++) {
                        buffer.putFloat(data[i][j][k]);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void writeData2ToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(data2Path))) {
            oos.writeObject(symbolIdx);
            oos.writeObject(dateIdx);
            oos.writeObject(dates);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static float convertDateStringToFloat(String dateString) {

        dateString.replaceAll(" {2}", " ");

        try {

                SimpleDateFormat sdf = new SimpleDateFormat(dateFormatStr, Locale.ENGLISH);
                Date date = sdf.parse(dateString);

                SimpleDateFormat sdfOutput = new SimpleDateFormat("yyMMdd");
                String formattedDate = sdfOutput.format(date);

                return Float.parseFloat(formattedDate);

        } catch (ParseException ignored) {
        }

        return 0.0f;
    }

    static class CustomDateComparator implements Comparator<Float> {
        @Override
        public int compare(Float date1, Float date2) {
            // 提取年份
            int year1 = getYear(date1);
            int year2 = getYear(date2);

            // 按年份比较
            if (year1 != year2) {
                return Integer.compare(year1, year2);
            }

            // 年份相同时，按照原始float值比较
            return Float.compare(date1, date2);
        }

        private int getYear(float date) {
            int yearPrefix = (int) (date / 10000);
            if (yearPrefix >= 70 && yearPrefix <= 99) {
                return 1900 + yearPrefix;
            } else {
                return 2000 + yearPrefix;
            }
        }
    }
}