package org.example;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.LinkedBlockingQueue;


public class util {
	public static void _operation(Connection conn, String sql) throws Exception {
		Statement curStmt = null;
		try {
			curStmt = conn.createStatement();
			conn.setAutoCommit(false);
			String[] ss = sql.split(";");
			for (String s : ss) {
				curStmt.addBatch(s);
			}
			curStmt.executeBatch();
			conn.commit();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			curStmt.close();
		}
	}

	public static Connection getConn() {
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/market?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
		String user = "root";
		String password = "gshlj1986";
		/*
		 * String url ="jdbc:sybase:Tds:sd-bdb5-07f0:4181/StkloanHist"; String
		 * user = "matrix_admin"; String password = "W4llstr3et";
		 */
		/*
		 * String url
		 * ="jdbc:sybase:Tds:lnysstmxdbn1u-vip.nam.nsroot.net:4110/StkloanHistArch";
		 * String user = "matrix_admin"; String password = "Jv3sheln";
		 */

		Connection conn = null;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			System.out.println("error in connecting db!");
			e.printStackTrace();
		}
		return conn;
	}

	public static void closeConn(Connection conn) {
		try {
			conn.close();
		} catch (Exception e) {
			System.out.println("error in closing db!");
			e.printStackTrace();
		}
	}

	public static List<String> initStockList() {
		List<String> stockList = new ArrayList<String>();
		try {
			Connection conn = getConn();
			Statement statement = conn.createStatement();
			// String sql = "select distinct SYMBOL FROM tbl_stk_ln";
			String sql = "select distinct symbol from tbl_stk_pd2 where symbol not in (select symbol from  tbl_stk_pd1) ";
			// String sql = "select symbol from Tbl_STK_L where symbol NOT LIKE
			// 'SHE39%' AND symbol NOT LIKE 'SHA000%'";
			// String sql = "select distinct SYMBOL FROM Thl_SKT_PD1";
			// String sql = "select * from stocks ";
			//// String sql = "select EXCHANGESYMBOL,min(DATE) as FDATE
			// ,max(DATE) as TDATE from Tbl_STK_PD group by EXCHANGE,SYMBOL";
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				//// s[2] = rs.getString("FDATE");
				//// s[3] = rs.getString("TDATE");
				stockList.add(rs.getString(1));
			}
			rs.close();
			statement.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stockList;
	}

	public static List<String> initStockListUS() {
		List<String> stockList = new ArrayList<String>();
		try {
			Connection conn = getConn();
			Statement statement = conn.createStatement();
			String sql = "select symbol from Tbl_STK_LUS order by symbol";
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				stockList.add(rs.getString(1));
			}
			rs.close();
			statement.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stockList;
	}




	/////////////////////////////////////////////////////////////////////////////////////
	static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");

	public static int getIntDate(Date date) {
		return Integer.parseInt(sdf.format(date));
	}

	static SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static String getStrDate(Date date) {
		return sdf1.format(date);
	}

	// d1 - d2//yyyymmdd
	public static int dayDiff(String d1, String d2) {
		try {
			return (int) ((sdf.parse(d1).getTime() - sdf.parse(d2).getTime()) / 86400000);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static double ptf2(double input) {
		double result = 0;
		try {
			result = new BigDecimal(input).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return result;
	}

	public static String getX(String smbl) {
		if (smbl == null)
			return null;
		else if (smbl.startsWith("00") || smbl.startsWith("200") || smbl.startsWith("300") || smbl.startsWith("399"))
			return "SHE";
		else if (smbl.startsWith("600") || smbl.startsWith("601") || smbl.startsWith("603") || smbl.startsWith("900"))
			return "SHA";
		else
			return null;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	public static double mean(double[] data) {
		double sum = 0;
		int len = data.length;
		for (int i = 0; i < len; i++) {
			sum += data[i];
		}
		return sum / len;
	}

	public static float mean(float[] data) {
		float sum = 0;
		int len = data.length;
		for (int i = 0; i < len; i++) {
			sum += data[i];
		}
		return sum / len;
	}

	public static double variance(double[] data) {
		double mean = mean(data);
		double sum = 0;
		int len = data.length;
		double delta = 0;
		for (int i = 0; i < len; i++) {
			delta = data[i] - mean;
			sum += (delta * delta);
		}
		return sum / len;
	}

	public static float variance(float[] data) {
		float mean = mean(data);
		float sum = 0;
		int len = data.length;
		float delta = 0;
		for (int i = 0; i < len; i++) {
			delta = data[i] - mean;
			sum += (delta * delta);
		}
		return sum / len;
	}

	public static double sd(double[] data) {
		return Math.sqrt(variance(data));
	}

	public static float sd(float[] data) {
		return (float) Math.sqrt(variance(data));
	}

	public static double covariance(double[] X, double[] Y) {
		double mx = mean(X);
		double my = mean(Y);
		int len = X.length == Y.length ? X.length : Math.min(X.length, Y.length);
		double sum = 0;
		for (int i = 0; i < len; i++) {
			sum += ((X[i] - mx) * (Y[i] - my));
		}
		return sum / len;
	}

	public static float covariance(float[] X, float[] Y) {
		float mx = mean(X);
		float my = mean(Y);
		int len = X.length == Y.length ? X.length : Math.min(X.length, Y.length);
		float sum = 0;
		for (int i = 0; i < len; i++) {
			sum += ((X[i] - mx) * (Y[i] - my));
		}
		return sum / len;
	}

	public static float PxyFloat(float[] X, float[] Y) {
		return covariance(X, Y) * 100 / (sd(X) * sd(Y));
	}

	public static double Pxy(double[] X, double[] Y) {
		double result = 0;
		try {
			result = new BigDecimal(covariance(X, Y) * 100 / (sd(X) * sd(Y))).setScale(2, BigDecimal.ROUND_HALF_UP)
					.doubleValue();
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return result;
	}

	public double PxyXcldFall(double[] p, double[] v) {
		double result = 0;
		double[] v1 = new double[v.length];
		double[] v2 = new double[v.length];
		for (int i = 0; i < v.length; i++) {
			if (i == 0) {
				v1[i] = 0;
				v2[i] = v[i + 1] - v[i];
			} else if (i == v.length - 1) {
				v1[i] = v[i] - v[i - 1];
				v2[i] = 0;
			} else {
				v1[i] = v[i] - v[i - 1];
				v2[i] = v[i + 1] - v[i];
			}
		}
		List<List<Integer>> ups = new LinkedList<List<Integer>>();
		List<Integer> up = new LinkedList<Integer>();
		for (int i = 0; i < v.length; i++) {
			if (v1[i] > 0 || v2[i] > 0)
				up.add(i);
			if (v1[i] > 0 && v2[i] <= 0) {
				ups.add(up);
				up = new LinkedList<Integer>();
			}
		}
		double sum = 0;
		int count = 0;
		for (List<Integer> up1 : ups) {
			int size = up1.size();
			double[] po = new double[size];
			double[] vo = new double[size];
			for (int i = 0; i < size; i++) {
				int tmp = up1.get(i);
				// System.out.print(tmp+":"+v[tmp]+"|");
				po[i] = p[tmp];
				vo[i] = v[tmp];
			}
			double pxy = Pxy(po, vo);
			sum += pxy * size;
			count += size;
			// System.out.println(size+"|"+pxy);
		}
		try {
			result = new BigDecimal(sum / count).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
		} catch (Exception e) {
			// e.printStackTrace();
		}
		return result;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	// 5,10,15,25 d 15,30
	// 0 f, 1 t, 2 stop or beyond, 3 fuquan
	public static int[][][] tj_unit(float open, float[] p, boolean fuquan) {
		int[][][] result = new int[4][2][2];
		int rng = p.length;
		float[] ch = new float[rng];
		if (p[rng - 1] == 0) {
			result[0][0][0] = 2;
			return result;
		}
		for (int i = 0; i < rng; i++) {
			ch[i] = (p[i] - open) * 100 / open;
		}
		if (fuquan) {
			if (ch[0] < -13 || ch[0] > 13) {
				result[0][0][0] = 3;
				return result;
			}
			for (int i = 1; i < rng; i++) {
				float tmp = (p[i] - p[i - 1]) * 100 / p[i - 1];
				if (tmp < -10.5 || tmp > 10.5) {
					result[0][0][0] = 3;
					return result;
				}
			}
		}
		float max1 = 0, max2 = 0, max3 = 0;
		float min1 = 99, min2 = 99, min3 = 99;
		for (int i = 0; i < 15; i++) {
			if (ch[i] > max1) {
				max1 = ch[i];
				result[1][1][1] = i;
			}
			if (ch[i] < min1) {
				min1 = ch[i];
				result[1][0][1] = i;
			}
		}
		for (int i = 15; i < 30; i++) {
			if (ch[i] > max2) {
				max2 = ch[i];
				result[2][1][1] = i;
			}
			if (ch[i] < min2) {
				min2 = ch[i];
				result[2][0][1] = i;
			}
		}
		for (int i = 30; i < rng; i++) {
			if (ch[i] > max3) {
				max3 = ch[i];
				result[3][1][1] = i;
			}
			if (ch[i] < min3) {
				min3 = ch[i];
				result[3][0][1] = i;
			}
		}
		if (5 <= max1 && max1 < 10)
			result[1][1][0] = 1;
		if (10 <= max1 && max1 < 15)
			result[1][1][0] = 2;
		if (15 <= max1 && max1 < 25)
			result[1][1][0] = 3;
		if (25 <= max1)
			result[1][1][0] = 4;
		if (5 <= max2 && max2 < 10)
			result[2][1][0] = 1;
		if (10 <= max2 && max2 < 15)
			result[2][1][0] = 2;
		if (15 <= max2 && max2 < 25)
			result[2][1][0] = 3;
		if (25 <= max2)
			result[2][1][0] = 4;
		if (5 <= max3 && max3 < 10)
			result[3][1][0] = 1;
		if (10 <= max3 && max3 < 15)
			result[3][1][0] = 2;
		if (15 <= max3 && max3 < 25)
			result[3][1][0] = 3;
		if (25 <= max3)
			result[3][1][0] = 4;
		if (-10 <= min1 && min1 < -5)
			result[1][0][0] = -1;
		if (-15 <= min1 && min1 < -10)
			result[1][0][0] = -2;
		if (-25 <= min1 && min1 < -15)
			result[1][0][0] = -3;
		if (-25 > min1)
			result[1][0][0] = -4;
		if (-10 <= min2 && min2 < -5)
			result[2][0][0] = -1;
		if (-15 <= min2 && min2 < -10)
			result[2][0][0] = -2;
		if (-25 <= min2 && min2 < -15)
			result[2][0][0] = -3;
		if (-25 > min2)
			result[2][0][0] = -4;
		if (-10 <= min3 && min3 < -5)
			result[3][0][0] = -1;
		if (-15 <= min3 && min3 < -10)
			result[3][0][0] = -2;
		if (-25 <= min3 && min3 < -15)
			result[3][0][0] = -3;
		if (-25 > min3)
			result[3][0][0] = -4;
		if (result[1][1][0] > 1 || result[2][1][0] > 1 || result[3][1][0] > 1)
			result[0][0][0] = 1;
		if (!(result[1][0][0] < 0 || result[2][0][0] < 0 || result[3][0][0] < 0)
				&& (result[1][1][0] == 1 || result[2][1][0] == 1 || result[3][1][0] == 1))
			result[0][0][0] = 1;
		return result;
	}

	/////////////////////////////////////////////////////////////////////////////////////
	public static void main(String[] args) {
	}
}
