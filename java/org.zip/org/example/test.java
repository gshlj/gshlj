package org.example;


public class test {

    public static void main(String[] args) {
        float[] a1 = {1,2,3,4};
        float[] a2 = {2,4,6,5};

        util u = new util();

            System.out.println(util.PxyFloat(a1,a2));
    }

}