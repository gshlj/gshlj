package org.example;

import java.io.*;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;

public class Step02LoadData {
    static Map<Float, Integer> symbolIdx = new HashMap<Float, Integer>();
    static Map<Float, Integer> dateIdx = new HashMap<Float, Integer>();
    static Float[] dates;
    static float[][][] data=null;

    public static void main(String[] args) {
        readData2FromFile();
        readDataFromFile();
        System.out.println(1);
    }

    public static void readData2FromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(Step01ReadBCP.data2Path))) {
            symbolIdx = (Map<Float, Integer>) ois.readObject();
            dateIdx = (Map<Float, Integer>) ois.readObject();
            dates = (Float[]) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static void readDataFromFile() {
        try (RandomAccessFile file = new RandomAccessFile(Step01ReadBCP.dataPath, "r");
             FileChannel channel = file.getChannel()) {

            data = new float[symbolIdx.size()][dateIdx.size()][7];

            long fileSize = channel.size();

            MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_ONLY, 0, fileSize);

            int numRows = symbolIdx.size();
            int numCols = dateIdx.size();
            for (int i = 0; i < numRows; i++) {
                for (int j = 0; j < numCols; j++) {
                    for (int k = 0; k < 7; k++) {
                        data[i][j][k]=buffer.getFloat();
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

