package testFuture.watcher;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

import testFuture.util;
import testFuture.load.priceEntity;

public class WatcherIG implements WatcherI {

 Watcher main;
 String url;

 public priceEntity getLatest() {
 SocketAddress addr = new InetSocketAddress("192.193.171.150", 8080);
 Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
 HttpURLConnection oConn = null;
 URL url;
 List<priceEntity> list = new LinkedList<priceEntity>();
 try {
 url = new URL(this.url);
 oConn = (HttpURLConnection) url.openConnection(proxy);
 oConn.setConnectTimeout(5000);
 oConn.connect();
 InputStream is = oConn.getInputStream();
 BufferedReader in = new BufferedReader(new InputStreamReader(is));
 String line = null;
 int count = 0;
 while ((line = in.readLine()) != null){
 if(count < 8){
 count ++;
 continue;
 }
 String[] s1 = line.split(",");
 if(s1.length < 6)
 continue;
 priceEntity e = new priceEntity();
 java.util.Date date = new java.util.Date();
 long time,a=0;
 if(s1[0].startsWith("a")){
 long adate = Long.parseLong(s1[0].substring(1, s1[0].length())+"000");
 time = adate;
 a = adate;
 }else{
 time = Long.parseLong(s1[0])*86400000l+a;
 }
 date.setTime(time);
 e.DATE = util.getIntDate(date);
 e.CLOSE = Float.parseFloat(s1[1]);
 e.HIGH = Float.parseFloat(s1[2]);
 e.LOW = Float.parseFloat(s1[3]);
 e.OPEN = Float.parseFloat(s1[4]);
 e.VOLUM = Long.parseLong(s1[5]);
 list.add(e);
 }
 in.close();
 } catch (Exception e) {
 e.printStackTrace();
 } finally {
 if (oConn != null) {
 oConn.disconnect();
 }
 }
 priceEntity ret = new priceEntity();
 if(list.size() == 0)
 return ret;
 int count = 0;
 int lastIdx = list.size()-1;
 ret.CLOSE = list.get(lastIdx).CLOSE;
 for (int i = lastIdx; count < main.interval && i >=0 ; i--){
 ret.VOLUM += list.get(i).VOLUM;
 ret.OPEN = list.get(i).OPEN;
 count++;
 }
 return ret;
 }

 public void setWatcher(Watcher w) {
 main = w;
 String x = util.getX(w.smbl);
 int uinterval = w.interval+1;
 //"http://finance.google.com/finance/getprices?q=603389&x=SHA&i=60&p=2m&f=d,c,h,l,o,v"
 url = "http://finance.google.com/finance/getprices?q="+w.smbl+"&x="+x+"&i=60&p="+uinterval+"m&f=d,c,h,l,o,v";
 }

}

