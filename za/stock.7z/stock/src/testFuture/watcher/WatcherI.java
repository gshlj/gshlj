package testFuture.watcher;

import testFuture.load.priceEntity;

public interface WatcherI {
 priceEntity getLatest();
 priceEntity getOpen();
 void setWatcher(Watcher w);
}

