package testFuture.watcher;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import testFuture.util;
import testFuture.load.priceEntity;

public class Watcher {
 
 static int interval = 5;
 String smbl = "300122";//"000830";//300122

	public static void main(String[] args) {
		Watcher main = new Watcher();
		// long av = main.getAv();
		WatcherI watcher = new WatcherISi();
		watcher.setWatcher(main);
		priceEntity open = watcher.getOpen();
		int lasttime = 930;
		while (true) {

			Date d = new java.util.Date();
			int time = d.getHours() * 100 + d.getMinutes();
			Calendar c = Calendar.getInstance();
			c.setTime(new Date());
			int day = c.get(Calendar.DAY_OF_WEEK);
			if (!((time >= 930 && time < 1137) || (time > 1300 && time < 1507)) || day == 1 || day == 7) {
				open = null;
				main.sleep1();
				continue;
			}
			if (open == null)
				open = watcher.getOpen();
			priceEntity pe = watcher.getLatest();
			if (open == null || pe == null) {
				main.sleep1();
				continue;
			}

			if (main.check(open, pe)) {
				new Thread("invalide value: " + util.ptf2((pe.CLOSE - open.OPEN) * 100 / open.OPEN) + "," + time + " "
						+ lasttime) {
					public void run() {
						int x = 0;
						int y = 0;
						JDialog jd = new JDialog();
						jd.setSize(10, 10);
						jd.setLocation(x, y);
						jd.setVisible(true);
						jd.setAlwaysOnTop(true);
						JOptionPane.showMessageDialog(jd, new JScrollPane(new JLabel(this.getName())));
						jd.setVisible(false);
					}
				}.start();
				lasttime = time;
				System.out.println("##");
			}
			System.out
					.println(d.getHours() + "" + d.getMinutes() + util.ptf2((pe.CLOSE - open.OPEN) * 100 / open.OPEN));
			main.sleep();
		}
	}
 
 int lastp = 0;
 private boolean check(priceEntity open, priceEntity pe){
 int p = (int) ((pe.CLOSE - open.OPEN)*100/open.OPEN);
 if(p!=lastp){
 lastp = p;
 return true;
 }
 return false;
 }
 
 private void sleep1(){
 try {
 Thread.sleep(60000);
 } catch (InterruptedException e) {
 e.printStackTrace();
 }
 }
 
 private void sleep(){
 try {
 Thread.sleep(interval*60000);
 } catch (InterruptedException e) {
 e.printStackTrace();
 }
 }
 
 public long getAv(){
 long av = 0;
 try {
 //System.out.println("queryPricea:"+new Date());
 Connection conn = util.getConn();
 Statement statement = conn.createStatement();
 //statement.setFetchSize(100000);
 //StringBuffer sb= new StringBuffer("select CONVERT(float,SYMBOL),substring(convert(char(8),DATE,112),3,8),CLOSEP,HIGH,LOW,OPENP,convert(float,VOLUM) FROM Tbl_STK_PD1 where DATE between '20150101' and '20171208' order by SYMBOL,DATE");
 //StringBuffer sb= new StringBuffer("select CONVERT(float,SYMBOL),substring(convert(char(8),DATE,112),3,8),CLOSEP,HIGH,LOW,OPENP,convert(float,VOLUM) FROM Tbl_STK_PD1 order by SYMBOL,DATE");
 StringBuffer sb= new StringBuffer("select avg(VOLUM)/240 from Tbl_STK_PD1 WHERE SYMBOL = '600036' and DATE BETWEEN dateadd(dd,-150,getdate()) and getdate()");
 ResultSet rs = statement.executeQuery(sb.toString());//rs.getFetchSize()
 while(rs.next()){
 av = rs.getLong(1);
 }
 rs.close();
 statement.close();
 conn.close();
 } catch (Exception e) {
 e.printStackTrace();
 }
 return av;
 }

}

