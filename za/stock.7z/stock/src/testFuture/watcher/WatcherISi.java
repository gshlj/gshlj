package testFuture.watcher;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import testFuture.util;
import testFuture.load.priceEntity;

public class WatcherISi implements WatcherI {

 Watcher main;
 String url;

 public priceEntity getOpen() {
 SocketAddress addr = new InetSocketAddress("192.193.171.150", 8080);
 Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
 HttpURLConnection oConn = null;
 URL url;
 priceEntity e = null;
 String date = util.getStrDate(new java.util.Date());
 try {
 url = new URL(this.url+"5");
 oConn = (HttpURLConnection) url.openConnection();
 oConn.setConnectTimeout(5000);
 oConn.connect();
 InputStream is = oConn.getInputStream();
 BufferedReader br = new BufferedReader(new InputStreamReader(is));
 String line = null;
 StringBuffer content = new StringBuffer("");
 while ((line = br.readLine( )) != null) {
 content.append(line);
 }
 JSONArray list = new JSONArray(content.toString( ));
 for(int j = 0 ; j < list.length( ) ; j++){
 JSONObject l = list.getJSONObject(j);
 e = new priceEntity();
 e.symbol = main.smbl;
 e.DATESTR = l.getString("day");
 e.CLOSE = Float.parseFloat(l.getString("close"));
 e.HIGH = Float.parseFloat(l.getString("high"));
 e.LOW = Float.parseFloat(l.getString("low"));
 e.OPEN = Float.parseFloat(l.getString("open"));
 e.VOLUM = Long.parseLong(l.getString("volume"));
 if(e.DATESTR.startsWith(date.substring(0, 10)))
 return e;
 }
 br.close();
 } catch (Exception ex) {
 ex.printStackTrace();
 } finally {
 if (oConn != null) {
 oConn.disconnect();
 }
 }
 return null;
 }
 
 public priceEntity getLatest() {
 SocketAddress addr = new InetSocketAddress("192.193.171.150", 8080);
 Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
 HttpURLConnection oConn = null;
 URL url;
 priceEntity e = null;
 try {
 url = new URL(this.url+"1");
 oConn = (HttpURLConnection) url.openConnection();
 oConn.setConnectTimeout(5000);
 oConn.connect();
 InputStream is = oConn.getInputStream();
 BufferedReader br = new BufferedReader(new InputStreamReader(is));
 String line = null;
 StringBuffer content = new StringBuffer("");
 while ((line = br.readLine( )) != null) {
 content.append(line);
 }
 JSONArray list = new JSONArray(content.toString( ));
 for(int j = 0 ; j < list.length( ) ; j++){
 JSONObject l = list.getJSONObject(j);
 e = new priceEntity();
 e.symbol = main.smbl;
 e.DATESTR = l.getString("day");
 e.CLOSE = Float.parseFloat(l.getString("close"));
 e.HIGH = Float.parseFloat(l.getString("high"));
 e.LOW = Float.parseFloat(l.getString("low"));
 e.OPEN = Float.parseFloat(l.getString("open"));
 e.VOLUM = Long.parseLong(l.getString("volume"));
 }
 br.close();
 } catch (Exception ex) {
 ex.printStackTrace();
 } finally {
 if (oConn != null) {
 oConn.disconnect();
 }
 }
 return e;
 }
 //http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol=sz300122&scale=60&ma=no&datalen=10

 public void setWatcher(Watcher w) {
 main = w;
 String x = util.getX(w.smbl);
 String s = "";
 if("SHE".equals("SHE"))
 s="sz"+w.smbl;
 else
 s="sh"+w.smbl;
 int uinterval = w.interval+1;
 url = "http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol="+s+"&scale=60&ma=no&datalen=";
 }
}

