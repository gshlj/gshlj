package testFuture.extract2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import testFuture.util;

public class S_CNDL {
	int dateback = 5102;// edit
	// public List<String> stocklist = util.initStockList();
	public int stocklist = 3605;
	float[][][] data = new float[stocklist][dateback][7];
	// 0 symbol, 1 date, 2 CLO5EP,3 HIGH,4 LOW,5 OPENP, 6 volumn
	Connection conn = util.getConn();
	util util1 = new util();

	float[] date = new float[dateback];

	boolean finished = false;

	LinkedBlockingQueue<float[]> resultQueue = new LinkedBlockingQueue<float[]>();

	// float [][] result = new float [stocklist][6];
	// 0 tdt, 1 tsmbl, 2 totalc, 3 t5c, 4 t10c, 5 edt, 6 ch5 , 7 ch10
	// select distinct DATE from Tbl_STK_PD1
	/*
	 * select CONVERT(float,SYMBOL),substring(convert(char(8),DATE,112),3,8),
	 * CLO5EP,HIGH,LOW,OPENP,convert(float,VOLUM) FROM Thl_SKT_PD1 where DATE
	 * between '20171207' and '20171208'
	 */
	public static void main(String[] args) {
		final S_CNDL s = new S_CNDL();
		System.out.println(new java.util.Date());
		s.data();
		s.dateidx();
		System.out.println(new java.util.Date());

		new Thread() {
			public void run() {
				s.output();
			}
		}.start();
		s.gothrough();
		System.out.println(new java.util.Date());

	}

	public void output() {
		StringBuffer sql = new StringBuffer();
		int counta = 0;
		int countp = 0;
		int total = 0;
		while (true) {
			try {
				float[] rst = resultQueue.poll(1000, TimeUnit.MILLISECONDS);
				if (rst != null) {
					//// 0 smbl, 1 {vate, 2 trend2, 3 trend, 4 ch1, 5 s, 6 d
					int s = (int) rst[5];
					int d = (int) rst[6];
					if (d - 1 < 0)
						continue;
					float open = data[s][d - 1][5];
					int rng = 80;
					float p[] = new float[rng];
					for (int di = d, i = 0; i < rng && di >= 0; di--, i++) {
						p[i] = data[s][di][2];
					}
					int[][][] r = util.tj_unit(open, p, true);
					System.out.println("\t" + rst[0] + "\t" + rst[1] + "\t trend2:" + -rst[2] + "\t trend:" + -rst[3]
							+ "\t ch1:" + rst[4] + "\t" + r[1][1][0] + "|" + r[1][0][0] + "\t" + r[2][1][0] + "|"
							+ r[2][0][0] + "\t" + r[3][1][0] + "|" + r[3][0][0] + "\t r" + r[0][0][0]);
					total++;
					if (r[0][0][0] == 1)
						countp++;
					if (r[0][0][0] < 2)
						counta++;
				}
				if (finished && resultQueue.size() == 0)
					break;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		System.out.print(total + "\t" + counta + "\t" + countp);
		if (counta > 0)
			System.out.print("\t" + countp * 100 / counta);
		System.out.println();
	}

	public void gothrough() {

		int refdaycnt = 150;// edit
		int refdaycnt2 = 20;// edit

		// Date dt1 = new Date();
		// Date dt2 = new Date();
		// System.out.println("utilCalPeakInUnit
		// cost:"+(dt2.getTime()-dt1.getTime()));

		float[] ref = new float[refdaycnt];
		for (int i = 0; i < refdaycnt; i++)
			ref[i] = i;
		float[] ref2 = new float[refdaycnt2];
		for (int i = 0; i < refdaycnt2; i++)
			ref2[i] = i;

		for (int d = 0; d < dateback - refdaycnt; d++) {
			float[][] cdata = new float[stocklist][refdaycnt];
			float[][] cdata2 = new float[stocklist][refdaycnt2];
			float[] avgbody = new float[stocklist];
			for (int i = 0; i < stocklist; i++) {
				float sum = 0;
				for (int j = 0; j < refdaycnt; j++) {
					if (data[i][j][2] == 0)
						break;
					cdata[i][j] = data[i][d + j + 1][2];
					if (j < refdaycnt2) {
						cdata2[i][j] = data[i][d + j + 1][2];
						float tmp = data[i][d + j][2] - data[i][d + j][5];
						sum += tmp > 0 ? tmp : -tmp;
					}
				}
				avgbody[i] = sum / refdaycnt2;
			}
			for (int s = 0; s < stocklist; s++) {
				if (cdata[s][refdaycnt - 1] == 0)
					continue;

				// 0 symbol, 1 date, 2 CLOSEP,3 HIGH,4 LOW,5 OPENP, 6 volumn
				//////////////////////////////////////////////////////////////////////////////////////////
				/*
				 * float min = 9999; for(int d1 = 0; d1 < refdaycnt; d1++){
				 * if(min > data[s][d+d1][2]) min = data[s][d+d1][2]; }
				 * if(!((data[s][d+1][2] - min)/min < 0.03)) continue; float ch
				 * = (data[s][d][2] - data[s][d+1][2])/data[s][d+1][2]; if(!(ch
				 * > 0.08)) continue; float c1 =
				 * Math.max(data[s][d+2][2],data[s][d][5]); float c2 =
				 * Math.min(data[s][d+2][5],data[s][d][2]); float ch1 =
				 * (body1)*100/data[s][d+2][5]; if(!(ch1 < -4)) continue;
				 * if(!((c2-c1)/body1 < -0.6)) continue; if(!(data[s][d+2][6] <
				 * data[s][d+1][6] && data[s][d+1][6] < data[s][d][6]))
				 * continue; if(I(data[s][d+2][6] < data[s][d][6])) continue;
				 * float trend = util1.PxyFloat(cdata[s], ref); if(I(trend >
				 * 60)) continue;
				 */
				float ch1 = (data[s][d + 2][2] - data[s][d + 2][5]) * 100 / data[s][d + 2][5];
				float ch2 = (data[s][d + 1][2] - data[s][d + 1][5]) * 100 / data[s][d + 1][5];
				float ch3 = (data[s][d][2] - data[s][d][5]) * 100 / data[s][d][5];
				float gap1 = (data[s][d + 2][2] - data[s][d + 1][5]) * 100 / data[s][d + 1][5];
				float gap2 = (data[s][d][4] - data[s][d + 1][3]) * 100 / data[s][d + 1][5];

				float body1 = data[s][d + 2][2] - data[s][d + 2][5];
				float shadow1 = data[s][d + 2][3] - data[s][d + 2][4];
				float body2 = data[s][d + 1][2] - data[s][d + 1][5];
				float shadow2 = data[s][d + 1][3] - data[s][d + 1][4];
				float body3 = data[s][d][2] - data[s][d][5];
				float shadow_celling = data[s][d][3] - data[s][d][5];

				/*
				 * if(1(data[s][d][0]== 600718 && data[s][d][1] ==81110))
				 * continue;
				 */

				/*
				 * if(!(gap1 > 0 )) continue;
				 */
				if (!(body1 < 0 && body3 > 0))
					continue;
				if (!(0.4 * avgbody[s] < -body1))///// if(I(1.2*avgbody[s] <
													///// -body1))
					continue;
				if (!(body3 / shadow_celling > 0.8))
					continue;
				if (!((ch2 < 0.2 || ch2 > -0.2) && (body1 / body2 > 3 || body1 / body2 < -3)))// star
					continue;
				float c1 = Math.max(data[s][d + 2][2], data[s][d][5]);
				float c2 = Math.min(data[s][d + 2][5], data[s][d][2]);
				if (!((c2 - c1) / body1 < -0.6 || data[s][d][2] > data[s][d + 2][5]))///// if(I((c2-c1)/body1
																						///// <
																						///// -0.6))
					continue;

				if (!(data[s][d + 2][6] < data[s][d + 1][6] && data[s][d + 1][6] < data[s][d][6]))
					continue;
				float min = 9999;
				for (int d1 = 0; d1 < refdaycnt2; d1++) {
					if (min > data[s][d + d1][2])
						min = data[s][d + d1][2];
				}
				if (data[s][d + 1][2] > min)///// data[s][d+1][4] > min
					continue;

				float trend2 = util1.PxyFloat(cdata2[s], ref2);
				if (!(trend2 > 80))
					continue;
				float trend = util1.PxyFloat(cdata[s], ref);
				if (!(trend < -75))
					continue;
				//////////////////////////////////////////////////////////////////////////////////////////
				float[] result = new float[7]; // 0 smbl, 1 date, 2 trend2, 3
												// trend, 4 ch1, 5 s, 6 d
				result[0] = data[s][d][0];
				result[1] = data[s][d][1];
				result[2] = trend2;
				result[3] = trend;// 0-(c2-c1)/body1;
				result[4] = ch1;
				result[5] = s;
				result[6] = d;
				resultQueue.add(result);
			}
		}

		finished = true;
	}

	public void data() {
		try {
			// System.out.println("queryPricea:"+new Date());
			Statement statement = conn.createStatement();
			// statement.setFetchSize(100000);
			// StringBuffer sb= new StringBuffer("select
			// CONVERT(float,SYMBOL),substring(convert(char(8),DATE,112),3,8),CLOSEP,HIG,LOW,OPENP,convert(float,VOLUM)
			// FROM Tbl_STK_PD1 where DATE between '20150101' and '20171208'
			// order by SYMBOL,DATE");
			// StringBuffer sb= new StringBuffer("select
			// CONVERT(float,SYMBOL),substring(convert(char(8),DATE,112),3,8),CLOSEP,HIGH,LOW,OPENP,convert(float,VOLUM)
			// FROM Thl_SKT_PD1 order by SYMBOL,DATE");

			// StringBuffer sb= new StringBuffer("select
			// CONVERT(float,substring(SYMBOL,4,6)),substring(convert(char(8),DATE,112),3,8),CLOSEPHIGH,LOW,OPENP,convert(float,VOLUM)
			// FROM Tbl_STK_PD where SYMBOL NOT LIKE mHE39%' AND SYMBOL NOT LIKE
			// mHA000%' AND DATE between dateadd(dd,-3000,'20171110') and
			// '20171110' order by SYMBOL,DATE desc");
			StringBuffer sb = new StringBuffer(
					"select CONVERT(float,SYMBOL),substring(convert(char(8),DATE,112),3,8),CLOSEP,HIGH,LOW,OPENP,convert(float,VOLUM) FROM Tbl_STK_PD1 order by SYMBOL,DATE desc");
			ResultSet rs = statement.executeQuery(sb.toString());// rs.getFetchSize()
			float sm = 0, dt = 0;
			int ism = -1, idt = 0;
			while (rs.next()) {
				float esm = rs.getFloat(1);
				if (esm != sm) {
					ism++;
					sm = esm;
					idt = 0;
				}
				data[ism][idt][0] = esm;
				data[ism][idt][1] = rs.getFloat(2);
				data[ism][idt][2] = rs.getFloat(3);
				data[ism][idt][3] = rs.getFloat(4);
				data[ism][idt][4] = rs.getFloat(5);
				data[ism][idt][5] = rs.getFloat(6);
				data[ism][idt++][6] = rs.getFloat(7);
			}
			rs.close();
			statement.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void dateidx() {
		for (int i = 0; i < dateback; i++) {
			float f = 0;
			for (int j = 0; j < stocklist; j++) {
				if (data[j][i][1] > f)
					f = data[j][i][1];
			}
			date[i] = f;
		}
	}

}
/*
 * float ch1 = (data[s][d+2][2] - {vata[s][d+2][5])*100/{vata[s][d+2][5]; float
 * ch2 = ({\Jata[s][d+1][2] - {\Jata[s][d+1][5])*100/data[s][d+1][5]; float ch3
 * = (data[s][d][2] - data[s][d][5])*100/data[s][d][5]; float gap1 =
 * (data[s][d+2][2] - data[s][d+1][5])*100/data[s][d+1][5]; float gap2 =
 * (data[s][d][4] - data[s][d+1][3])*100/data[s][d+1][5];
 * 
 * float body1 = data[s][d+2][2] - data[s][d+2][5]; float shadow1 =
 * data[s][d+2][3] - data[s][d+2][4]; float body2 = data[s][d+1][2] -
 * data[s][d+1][5]; float shadow2 = data[s][d+1][3] - data[s][d+1][4]; float
 * body3 = data[s][d][2] - data[s][d][5]; float shadow_celling = data[s][d][3] -
 * data[s][d][5];
 * 
 * if(!(gap1 > 0 )) continue; if(!(body1<0 && hody3 >0)) continue;
 * if(!(0.8*avgbody[s] < -body1))J/////if(!(1.2*avgbody[s] < -body1)) continue;
 * if(!(body3/shadow_celling > 0.6))J////0.6 or more continue; if(!((ch2 <0.2 ||
 * ch2> -0.2) && (body1/body2 > 3 || body1/body2 <-3)))//star continue; float c1
 * = Math.max(data[s][d+2][2],data[s][d][5]); float c2 =
 * Math.min(data[s][d+2][5],data[s][d][2]); if(!((c2-c1)/body1 < -0.6 ||
 * data[s][d][2] > data[s][d+2][5]))J/////if(!((c2-c1)/body1 < -0.6)) continue;
 * 
 * 
 * if(!(data[s][d+2][6] < data[s][d+1][6] && data[s][d+1][6] < data[s][d][6]))
 * continue; //f(3th long up shadow) smbl:300459.0 date:170412.0 //f(3th long up
 * shadow) smbl:300459.0 date:170509.0 //strickly a star? hesitate //600718
 * 80820 81110 float min = 9999; for(int d1 = 0; d1 < refdaycnt; d1++){ if(min >
 * data[s][d+d1][2]) min = data[s][d+d1][2]; } if(data[s][d+1][2] >. min)
 * continue; float trend = util1.PxyFloat(cdata[s], ref); (Jf(!(trend > 50))
 * continue;
 * 
 */
