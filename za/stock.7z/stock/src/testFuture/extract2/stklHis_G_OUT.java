package testFuture.extract2;
import java.awt.*; 
import java.awt.event.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

import javax.swing.*; 
import javax.swing.table.*; 
 
/** 
* @version 1.0 11/09/98 
*/ 
public class stklHis_G_OUT extends JFrame { 
 
 public stklHis_G_OUT(){ 
 /*super( "JButtonTable Example" ); */
 DefaultTableModel dm = new DefaultTableModel(); 
 dm.setDataVector(new Object[][]{{"1","foo"}, 
 {"2","bar"}}, 
 new Object[]{"String","bt"});
 JTable table = new JTable(dm); 
 //table.getColumn("bt").setCellRenderer(new ButtonRenderer()); 
 table.getColumn("bt").setCellEditor(new ButtonEditor(new JCheckBox())); 
 JScrollPane scroll = new JScrollPane(table); 
 getContentPane().add( scroll ); 
 
 JButton cxButton = new JButton("CX");
 cxButton.setBounds(0, 0, 20,15);
 scroll.add(cxButton);
 
 setSize( 800, 400 ); 
 setVisible(true); 
 table.getTableHeader().addMouseListener(new TableHeaderMouseListener(table) );
 this.addWindowListener(new WindowAdapter() { 
 public void windowClosing(WindowEvent e) { 
 System.exit(0); 
 } 
 }); 
 } 
 
 JTable table;
 DefaultTableModel model;
 Object[][] dataVector;
 Object[] columnIdentifiers;
 int dateIdxs = -1;
 
 public stklHis_G_OUT(Object[][] data, Object[] column){ 
 
 model = new DefaultTableModel(); 
 model.setDataVector(data,column);
 table = new JTable(model); 
 table.setRowHeight(20);
 table.setFont(new Font("Serif", Font.PLAIN, 20));
 Color ivory = new Color(199, 237, 204);
 table.setBackground(ivory);
 
 //table.getColumn("bt").setCellRenderer(new ButtonRenderer()); 
 table.getColumn("bt").setCellEditor(new ButtonEditor(new JCheckBox())); 
 JScrollPane scroll = new JScrollPane(table); 
 getContentPane().add( scroll ); 
 
 JButton rtnButton = new JButton("R");
 rtnButton.setBounds(0, 0, 20,15);
 scroll.add(rtnButton);
 
 setSize( 800, 400 ); 
 setVisible(true); 
 table.getTableHeader().addMouseListener(new TableHeaderMouseListener(table) );
 //((DefaultTableModel)table.getModel()).getDataVector();
 
 calSmry(-1);
 dataVector = data;
 columnIdentifiers = column;
 rtnButton.addActionListener(new ActionListener() {
 public void actionPerformed(ActionEvent e) {
 model.setDataVector(dataVector, columnIdentifiers);
 table.getColumn("bt").setCellEditor(new ButtonEditor(new JCheckBox())); 
 calSmry(-1);
 }
 });
 } 
 
 
 
 public static void main(String[] args) { 
 stklHis_G_OUT frame = new stklHis_G_OUT(); 
 } 
 
 double getTableData(int row, int column){
 Object tmp = table.getValueAt(row, column);
 double result = Double.parseDouble(tmp+"");
 if(column != dateIdxs)
 return result;
 return stklHis_data.getDDate((float) result);
 }
 
 class TableHeaderMouseListener extends MouseAdapter {
 
 private JTable table;
 private int order = 0;
 
 public TableHeaderMouseListener(JTable table) {
 this.table = table;
 }
 public void mouseClicked(MouseEvent event) {
 Point point = event.getPoint();
 int column = table.columnAtPoint(point);
 
 int b = event.getButton();
 SortOrder so = SortOrder.UNSORTED;
 //System.out.println("Column header " + column + " is clicked. button:"+b);
 if (b == event.BUTTON1) {
 order++;
 if(order > 2)
 order = 0;
 switch (order) {
 case 0:
 break;
 case 1:
 so = SortOrder.ASCENDING;
 break;
 case 2:
 so = SortOrder.DESCENDING;
 break;
 default:
 }
 TableRowSorter<TableModel> sorter = new TableRowSorter<TableModel>(table.getModel());
 table.setRowSorter(sorter);
 List<RowSorter.SortKey> sortKeys = new ArrayList<>(25);
 sortKeys.add(new RowSorter.SortKey(column, so));
 sorter.setSortKeys(sortKeys);
 table.getColumn("bt").setCellEditor(new ButtonEditor(new JCheckBox())); 
 return;
 }
 JPanel panel = new JPanel();
 JTextField txf1 = new JTextField(20);
 JTextField txf2 = new JTextField(20);
 panel.add(txf1);
 panel.add(txf2);
 
 try {
 if(!"bt".equals(table.getColumnName(column))){
 int rcount = table.getRowCount();
 double tmp = 0;
 if(rcount > 0)
 tmp = getTableData(0,column);
 else
 return;
 double min,max;
 min=max=tmp;
 for(int i = 0;i < rcount; i++){
 double tmp2 = getTableData(i,column);
 if(tmp2 < min)
 min = tmp2;
 if(tmp2 > max)
 max= tmp2;
 }
 if(column==dateIdxs){
 txf1.setText((int)min+"");
 txf2.setText((int)max+"");
 }else{
 txf1.setText(min+"");
 txf2.setText(max+"");
 }
 }
 
 
 Object[] options = { panel, "OK" };
 int reply = JOptionPane.showOptionDialog(table, null, null, JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, "OK");
 if(reply != 1)
 return;
 if("bt".equals(table.getColumnName(column))){
 return;
 }
 List <Object[]>datalist = new LinkedList<Object[]>();
 int size = model.getDataVector().size();
 double min,max;
 min = Double.parseDouble(txf1.getText());
 max = Double.parseDouble(txf2.getText());
 for(int i = 0 ; i < size ; i ++){
 double value = getTableData(i,column);
 if(value >= min && value <= max){
 Object [] row = ((Vector)(model.getDataVector().get(i))).toArray();
 datalist.add(row);
 }
 }
 Object[] s = (Object[]) datalist.toArray();
 Object[][] aa = new Object[s.length][];
 for (int i = 0; i < s.length; i++) {
 aa[i] = (Object[]) s[i];
 }
 model.setDataVector(aa, columnIdentifiers);
 calSmry(-1);
 table.getColumn("bt").setCellEditor(new ButtonEditor(new JCheckBox())); 
 } catch (Exception e) {
 txf1.setText("error");
 e.printStackTrace();
 }
 }
 }
 
 
 class ButtonEditor extends DefaultCellEditor {
 protected JButton button; 
 private String label; 
 private boolean isPushed; 
 public ButtonEditor(JCheckBox checkBox) { 
 super(checkBox); 
 button = new JButton(); 
 button.setOpaque(true); 
 button.addActionListener(new ActionListener() { 
 public void actionPerformed(ActionEvent e) { 
 fireEditingStopped(); 
 } 
 }); 
 } 
 public Component getTableCellEditorComponent(JTable table, Object value, 
 boolean isSelected, int row, int column) { 
 if (isSelected) { 
 button.setForeground(table.getSelectionForeground()); 
 button.setBackground(table.getSelectionBackground()); 
 } else{ 
 button.setForeground(table.getForeground()); 
 button.setBackground(table.getBackground()); 
 } 
 label = (value ==null) ? "" : value.toString(); 
 button.setText( label ); 
 isPushed = true; 
 
 float smbl = (float) table.getValueAt(row, 0);
 float date = (float) table.getValueAt(row, 1);
 stklHis_G_K k = new stklHis_G_K(instance);
 k.pv = instance.queryK(smbl, date, instance.p2_before, instance.p2_after);
 k.baseIdx = (int) date;
 k.generate();
 
 return button; 
 } 
 public Object getCellEditorValue() { 
 if (isPushed) { 
 //JOptionPane.showMessageDialog(button ,label + ": Ouch!"); 
 // System.out.println(label + ": Ouch!"); 
 } 
 isPushed = false; 
 return new String( label ) ; 
 } 
 
 public boolean stopCellEditing() { 
 isPushed = false; 
 return super.stopCellEditing(); 
 } 
 protected void fireEditingStopped() { 
 super.fireEditingStopped(); 
 } 
 } 
 
 class ButtonRenderer extends JButton implements TableCellRenderer { 
 public ButtonRenderer() { 
 setOpaque(true); 
 } 
 
 public Component getTableCellRendererComponent(JTable table, Object value, 
 boolean isSelected, boolean hasFocus, int row, int column) { 
 if (isSelected) { 
 setForeground(table.getSelectionForeground()); 
 setBackground(table.getSelectionBackground()); 
 } else{ 
 setForeground(table.getForeground()); 
 setBackground(UIManager.getColor("Button.background")); 
 } 
 setText( (value ==null)? "" : value.toString() ); 
 return this; 
 } 
 } 
 stklHis_data instance = null;
 
 public void calSmry(int column){
 if(column < 0)
 column = table.getColumn("r").getModelIndex();
 int rowcnt = table.getRowCount();
 int counta = 0;
 int countp = 0;
 int total = 0;
 for(int i = 0 ; i < rowcnt ; i++){
 total++;
 int r = (Integer)table.getValueAt(i, column);
 if (r == 1)
 countp++;
 if (r < 2)
 counta++;
 }
 int rt = 0;
 if (counta > 0)
 rt = countp * 100 / counta;
 Object item[] = { total ,counta ,countp,rt,"","","","", "" };
 //model.addRow(item);
 String summary = total + "," + counta + "," + countp;
 if (counta > 0)
 summary += ("," + countp * 100 / counta);
 this.setTitle(summary);
 }
} 
 
 

