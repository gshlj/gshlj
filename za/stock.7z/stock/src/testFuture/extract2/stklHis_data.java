package testFuture.extract2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import testFuture.util;

public class stklHis_data {
	public int dateback = 6000;// edit
	public int stocklist = 4000;// 3605;
	float[][][] data = new float[stocklist][dateback][7];
	// 0 symbol, 1 date, 2 CLOSEP,3 HIGH,4 LOW,5 OPENP, 6 volumn
	Connection conn = util.getConn();

	float[] date = new float[dateback];

	static double getDDate(float fdate) {
		if (fdate == 0)
			return 0;
		double ddate = fdate;
		if (fdate > 500001)
			ddate += 19000000;
		else
			ddate += 20000000;
		return ddate;
	}

	public void data() {
		try {
			Statement statement = conn.createStatement();
			StringBuffer sb = new StringBuffer(
					"select CONVERT(SYMBOL,DECIMAL),convert(right(date_format(DATE, '%Y%m%d'),6),DECIMAL),"
							+ "CLOSEP,HIGH,LOW,OPENP,convert(VOLUM,DECIMAL) FROM tbl_stk_pd1 "
							//+ " WHERE DATE BETWEEN '20180101' AND '20180919' AND SYMBOL = '002353'  "
							+ " WHERE DATE BETWEEN '20150101' AND '20190308'  "
							+ "order by SYMBOL,DATE desc");
			ResultSet rs = statement.executeQuery(sb.toString());// rs.getFetchSize()
			float sm = 0, dt = 0;
			int ism = -1, idt = 0;
			while (rs.next()) {
				float esm = rs.getFloat(1);
				if (esm != sm) {
					ism++;
					sm = esm;
					idt = 0;
				}
				data[ism][idt][0] = esm;
				data[ism][idt][1] = rs.getFloat(2);
				data[ism][idt][2] = rs.getFloat(3);
				data[ism][idt][3] = rs.getFloat(4);
				data[ism][idt][4] = rs.getFloat(5);
				data[ism][idt][5] = rs.getFloat(6);
				data[ism][idt++][6] = rs.getFloat(7);
			}
			rs.close();
			statement.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void dateidx() {
		for (int i = 0; i < dateback; i++) {
			float f = 0;
			for (int j = 0; j < stocklist; j++) {
				if (data[j][i][1] > f)
					f = data[j][i][1];
			}
			date[i] = f;
		}
	}

	stklHis_G_LG gui = null;

	public void loadData() {
		System.out.println(new java.util.Date());
		data();
		dateidx();
		System.out.println(new java.util.Date());
		gui.okButton.setEnabled(true);
		gui.cxButton.setEnabled(true);
	}

	int p2_before = 100;
	int p2_after = 50;

	public float[][] queryK(float smbl, float date, int before, int after) {
		int sidx = -1;
		int didx = -1;
		out: for (int s = 0; s < stocklist; s++) {
			for (int d = dateback - 1; d >= 0; d--) {
				// 0 symbol, 1 date, 2 CLOSEP,3 HIGH,4 LOW,5 OPENP, 6 volumn
				if (data[s][d][0] == smbl && getDDate(data[s][d][1]) >= getDDate(date)) {
					sidx = s;
					didx = d;
					break out;
				}
			}
		}
		if (sidx == -1 || didx == -1)
			return null;
		int f = didx + before;
		int t = didx - after;
		int didxf = -1;
		int didxt = -1;
		for (int i = f; i >= t; i--) {
			if (i < 0)
				break;
			if (i > dateback)
				continue;
			if (data[sidx][i][2] == 0)
				continue;
			if (didxf == -1)
				didxf = i;
			didxt = i;
		}
		int size = didxf - didxt + 1;
		float[][] result = new float[size][7];
		for (int i = 0; i < size; i++) {
			result[i] = data[sidx][didxf - i];// no update to confilct
		}
		return result;
	}

	public float[][] queryKD(float smbl, int from, int to) {
		// [from to)
		int sidx = -1;
		int didxf = -1;
		int didxt = -1;
		boolean founds = false;
		out: for (int s = 0; s < stocklist; s++) {
			for (int d = dateback - 1; d >= 0; d--) {
				if (data[s][d][2] > 0 && data[s][d][0] != smbl)
					break;
				if (!founds && data[s][d][0] == smbl) {
					sidx = s;
					founds = true;
				}
				// 0 s, 1 date, 2 c,3 h,4 l,5 o, 6 v
				if (getDDate(data[s][d][1]) >= getDDate(from) && getDDate(data[s][d][1]) < getDDate(to)) {
					if (didxf == -1)
						didxf = d;
					didxt = d;
				}
			}
			if (founds)
				break out;
		}
		if (sidx == -1 || didxf == -1)
			return null;
		int size = didxf - didxt + 1;
		float[][] result = new float[size][7];
		for (int i = 0; i < size; i++) {
			result[i] = data[sidx][didxf - i];// no update to confilct
		}
		return result;
	}

}
