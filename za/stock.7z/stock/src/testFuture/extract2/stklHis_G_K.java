package testFuture.extract2;

import java.awt.Color;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.awt.Paint;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import org.jfree.data.time.*;
import org.jfree.data.time.Day;
import org.jfree.data.time.ohlc.OHLCSeries;
import org.jfree.data.time.ohlc.OHLCSeriesCollection;
import org.jfree.data.xy.XYDataset;
import org.jfree.util.ShapeUtilities;
import org.jfree.chart.renderer.xy.*;
import org.jfree.chart.axis.*;
import org.jfree.chart.event.PlotChangeEvent;
import org.jfree.chart.plot.*;
import org.jfree.chart.*;

public class stklHis_G_K {

	public float[][] pv = null;
	public float[][] gruppy = null;
	public int dtf = 20070820;
	public int dtt = 20070929;
	public int baseIdx = 0;

	public boolean flag_k = true;
	public boolean flag_g = false;

	public stklHis_G_K(stklHis_data data) {
		this.data = data;
	}

	void loadPVSeries(OHLCSeries series_p, TimeSeries series_v) {
		if (pv == null)
			return;
		// 0 symbol, 1 date, 2 CLOSEP,3 HIGH,4 LOW,5 OPENP, 6 volumn
		Day max = null;
		dtf = (int) stklHis_data.getDDate(pv[0][1]);
		dtt = dtf;
		for (float[] item : pv) {
			if (item[1] == 0)
				continue;
			int date = (int) stklHis_data.getDDate(item[1]);
			if (dtf > date)
				dtf = date;
			Day tmp = new Day(date % 100, date % 10000 / 100, date / 10000);
			series_p.add(tmp, item[5], item[3], item[4], item[2]);
			series_v.add(tmp, item[6] / 100);
			if (dtt <= date) {
				dtt = date;
				max = tmp;
			}
		}
		Day next = (Day) max.next();
		dtt = next.getYear() * 10000 + next.getMonth() * 100 + next.getDayOfMonth();
	}

	void loadGruppySeries(TimeSeriesCollection collection_gruppy) {/*
		int[] sl = { 3, 5, 8, 10, 12, 15, 30, 35, 40, 45, 50, 60 };
		int slen = sl.length;
		int slmax = sl[slen - 1];
		if (pv == null)
			return;
		
		float[][] orig =  extendDate(slmax) ;
				
		for (int i = 0; i < slen; i++) {
			float[][] gruppy = calOnOriginal(orig, sl[i], idx1);
			TimeSeries series = array2series(gruppy);
			collection_gruppy.addSeries(series);
		}
	*/}
	
	float[][] extendDate( int off) {
		float[][] predata = data.queryK(pv[0][0], dtf % 1000000, off, 0);
		if (predata[predata.length - 1][1] == pv[0][1])
			predata = Arrays.copyOfRange(predata, 0, predata.length - 1);
		int gsize = pv.length + predata.length;
		int pvsize = pv.length;
		int idx1 = predata.length;
		float[][] orig = new float[gsize][2];
		for (int i = 0; i < pvsize; i++) {
			orig[idx1 + i][0] = pv[i][1];
			orig[idx1 + i][1] = pv[i][2];
		}
		int prelength = predata.length;
		int j = 0;
		for (int i = 0; i < idx1; i++) {
			if (prelength + i < off - 1)
				continue;
			orig[i][0] = predata[j][1];
			orig[i][1] = predata[j++][2];
		}
		return orig;
	}

	float[][] calOnOriginal(float[][] orig, int off, int idx1) {
		float[][] data = new float[pv.length][2];
		int last = orig.length - 1;
		for (int i = last; i >= idx1; i--) {
			int idx = i - idx1;
			data[idx][0] = orig[i][0];
			int count = 1;
			float value = orig[i][1];
			for (int j = 1; j < off; j++) {
				if (orig[i - j][1] == 0)
					break;
				value += orig[i - j][1];
				count++;
			}
			data[idx][1] = value / count;
		}
		return data;
	}

	TimeSeries array2series(float[][] data) {
		TimeSeries series = new TimeSeries("");
		for (float[] item : data) {
			int date = (int) stklHis_data.getDDate(item[0]);
			Day tmp = new Day(date % 100, date % 10000 / 100, date / 10000);
			series.add(tmp, item[1]);
		}

		return series;
	}

	double[] getHL(XYDataset collection_p) {
		double[] hl = new double[2];
		double highValue = 0;
		double minValue = 0;
		// set max min
		// int seriesCount = collection_p.getSeriesCount();
		for (int i = 0; i < 1; i++) {
			int itemCount = collection_p.getItemCount(i);
			if (itemCount == 0)
				return hl;
			highValue = minValue = collection_p.getYValue(0, 0);
			for (int j = 0; j < itemCount; j++) {
				if (highValue < collection_p.getYValue(i, j)) {// getHighValue
					highValue = collection_p.getYValue(i, j);
				}
				if (minValue > collection_p.getYValue(i, j)) {// getLowValue
					minValue = collection_p.getYValue(i, j);
				}
			}
		}
		hl[0] = highValue;
		hl[1] = minValue;
		return hl;
	}

	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	KFrame frame;

	public void generate() {

		JFreeChart chart = generat1();
		frame = new KFrame(pv.length + "", chart, true);
		frame.addKeyListener(frame);
		frame.setFocusable(true);

		frame.pack();
		frame.setSize(1200, 800);
		frame.setVisible(true);

	}

	JFreeChart generat1() {
		final Paint upPaint = Color.RED;
		final Paint downPaint = Color.GREEN;
		OHLCSeries series_p = new OHLCSeries("");
		TimeSeries series_v = new TimeSeries("");
		this.loadPVSeries(series_p, series_v);
		final OHLCSeriesCollection collection_p = new OHLCSeriesCollection();// final
		collection_p.addSeries(series_p);
		TimeSeriesCollection collection_v = new TimeSeriesCollection();
		collection_v.addSeries(series_v);

		DateAxis x_p = new DateAxis(); // x
		x_p.setAutoRange(false);
		try {
			x_p.setRange(dateFormat.parse("" + dtf), dateFormat.parse("" + dtt));// +1day
		} catch (Exception e) {
			e.printStackTrace();
		}
		x_p.setTimeline(SegmentedTimeline.newMondayThroughFridayTimeline());// uncommon// known// method// to// filter// out// sat// and// sun
		x_p.setAutoTickUnitSelection(false);// zi dong xuan qu ke du zhi
		x_p.setTickMarkPosition(DateTickMarkPosition.MIDDLE);// set mark
																// position
		x_p.setStandardTickUnits(DateAxis.createStandardDateTickUnits());// set// standard// date// tick// unit
		x_p.setTickUnit(new DateTickUnit(DateTickUnit.MONTH, 1));// week unit
		x_p.setDateFormatOverride(new SimpleDateFormat("yyMMdd"));

		XYPlot plot1 = null;

		if (flag_k) {
			CandlestickRenderer candlestickRender = new CandlestickRenderer();
			candlestickRender.setUseOutlinePaint(true); // set for china
			// candlestickRender.setCandleWidth(5);
			candlestickRender.setAutoWidthMethod(CandlestickRenderer.WIDTHMETHOD_AVERAGE);// witdth				// of				// cndl
			candlestickRender.setAutoWidthGap(0.001);
			candlestickRender.setUpPaint(upPaint);
			candlestickRender.setDownPaint(downPaint);
			NumberAxis y_p = new NumberAxis();// y
			y_p.setAutoRange(false);
			double[] hl = getHL(collection_p);
			y_p.setRange(hl[1] * 0.9, hl[0] * 1.1);
			y_p.setTickUnit(new NumberTickUnit((hl[0] * 1.1 - hl[1] * 0.9) / 10));// set		// tick		// unit
			plot1 = new XYPlot(collection_p, x_p, y_p, candlestickRender);//
			
			/*TimeSeriesCollection collection_gruppy = new TimeSeriesCollection();
			loadGruppySeries(collection_gruppy);
			StandardXYItemRenderer renderer_gruppy = new StandardXYItemRenderer();// XYItemRenderer
			plot1.setDataset(1, collection_gruppy);
			plot1.setRenderer(1, renderer_gruppy);*/
		} else if (flag_g) {
			TimeSeriesCollection collection_gruppy = new TimeSeriesCollection();
			loadGruppySeries(collection_gruppy);
			NumberAxis y_gruppy = new NumberAxis();// set y of char 2 refer the
													// setting of char1 y
			y_gruppy.setAutoRange(false);
			double[] hl = getHL(collection_gruppy);
			y_gruppy.setRange(hl[1] * 0.9, hl[0] * 1.1);
			y_gruppy.setTickUnit(new NumberTickUnit((hl[0] * 1.1 - hl[1] * 0.9) / 4));
			XYLineAndShapeRenderer renderer_gruppy = new XYLineAndShapeRenderer();// XYItemRenderer
			plot1 = new XYPlot(collection_gruppy, null, y_gruppy, renderer_gruppy);
			setGruppy(renderer_gruppy);
		}

		XYBarRenderer xyBarRender = new XYBarRenderer() {
			private static final long serialVersionUID = 1L;// to avoid warning  ?

			public Paint getItemPaint(int i, int j) {// render v the same color with p
				if (collection_p.getCloseValue(i, j) > collection_p.getOpenValue(i, j)) {// set				// color
					return upPaint;
				} else {
					return downPaint;
				}
			}
		};
		xyBarRender.setMargin(0.1);// set gap between bars
		NumberAxis y_v = new NumberAxis();// set y of char 2 refer the setting
											// of char1 y
		y_v.setAutoRange(false);
		double[] hl = getHL(collection_v);
		y_v.setRange(hl[1] * 0.9, hl[0] * 1.1);
		y_v.setTickUnit(new NumberTickUnit((hl[0] * 1.1 - hl[1] * 0.9) / 4));
		XYPlot plot2 = new XYPlot(collection_v, null, y_v, xyBarRender);// x is// null// as it// will// share// the// common// x// with// char1
		CombinedDomainXYPlot combineddomainxyplot = new CombinedDomainXYPlot(x_p);// share		// common		// x

		if (plot1 != null)
			combineddomainxyplot.add(plot1, 2);// 2/3
		combineddomainxyplot.add(plot2, 1);// 1/3
		combineddomainxyplot.setGap(10);

		if (baseIdx > 0 && baseIdx < 1000000) {
			int d = (int) stklHis_data.getDDate(baseIdx);
			Day tmp = new Day(d % 100, d % 10000 / 100, d / 10000);
			ValueMarker marker = new ValueMarker(tmp.getLastMillisecond());
			marker.setPaint(Color.black);
			if (plot1 != null)
				plot1.addDomainMarker(marker);
			plot2.addDomainMarker(marker);
		}

		return new JFreeChart("", JFreeChart.DEFAULT_TITLE_FONT, combineddomainxyplot, false);
	}

	void setGruppy(XYLineAndShapeRenderer renderer_gruppy) {
		Shape cross = ShapeUtilities.createDiagonalCross(0, 0);
		for (int i = 0; i < 12; i++) {
			renderer_gruppy.setSeriesShape(i, cross);
			renderer_gruppy.setSeriesPaint(i, Color.black);
		}
	}

	class KFrame extends ChartFrame implements KeyListener {
		public KFrame(String title, JFreeChart chart, boolean scrollPane) {
			super(title, chart, scrollPane);
			// x_p.setRange(dateEormat.parse("20150401"),dateEormat.parse("20150701"));
		}

		public void keyTyped(KeyEvent e) {
		}

		public void keyPressed(KeyEvent e) {
			int code = e.getKeyCode();

			int stepf = 10;
			int stept = 10;
			int from = dtf;
			int to = dtt;
			if (code == KeyEvent.VK_LEFT) {
				stepf = -stepf;
				stept = -stept;
			} else if (code == KeyEvent.VK_RIGHT) {
			} else if (code == KeyEvent.VK_UP) {
				stepf = -stepf * 2;
				stept = stept * 2;
			} else if (code == KeyEvent.VK_DOWN) {
				stepf = stepf;
				stept = -stept;
			} else if (code == KeyEvent.VK_G) {
				flag_g = true;
				flag_k = false;
				frame.getChartPanel().setChart(generat1());
				return;
			} else if (code == KeyEvent.VK_K) {
				flag_k = true;
				flag_g = false;
				frame.getChartPanel().setChart(generat1());
				return;
			} else
				return;
			Calendar c = Calendar.getInstance();
			try {
				c.setTime(dateFormat.parse(from + ""));
				c.add(Calendar.DATE, stepf);
				Date fd = c.getTime();
				from = Integer.parseInt(dateFormat.format(fd));
				c.setTime(dateFormat.parse(to + ""));
				c.add(Calendar.DATE, stept);
				fd = c.getTime();
				to = Integer.parseInt(dateFormat.format(fd));
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
			if (pv == null)
				return;
			float smbl = 0;
			for (int i = 0; i < pv.length; i++) {
				if (pv[i][0] != 0) {
					smbl = pv[i][0];
				}
			}
			float[][] d = data.queryKD(smbl, from % 1000000, to % 1000000);
			if (d == null)
				return;
			pv = d;
			frame.setTitle(pv.length + "");
			frame.getChartPanel().setChart(generat1());
			dtf = from;
			dtt = to;
			return;
		}

		public void keyReleased(KeyEvent e) {
		}
	}

	stklHis_data data;

	public static void main(String args[]) {
		int i = 2;
		float f = (float) 2.0;
		System.out.println(i == f);

	}
}
