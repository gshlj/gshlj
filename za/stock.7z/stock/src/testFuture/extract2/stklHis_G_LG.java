package testFuture.extract2;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class stklHis_G_LG {

 private int height = 400;
 private final int width = 280;
 private final Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
 private final int x0 = (screen.width - width) / 4;
 private final int y0 = (screen.height - height) / 4;

 public stklHis_G_LG() {
 JFrame login = new JFrame("MATRIX Login : ");

 JPanel content = new JPanel();
 // content.setBackground(SystemColor.desktop);
 content.setLayout(null);
 login.getContentPane().add(BorderLayout.CENTER, content);
 content.setBounds(0, 29, 280, 330);

 int x = 15, y = 15;
 int rp = 10, cp = 10;
 int w = 60;
 int h = 25;

 JLabel label = new JLabel("T: ");
 label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
 content.add(label);
 label.setBounds(x, y, w, h);

 field11 = new JTextField("80");//85  100
 content.add(field11);
 field11.setBounds(x + 1 * (w + cp), y, w, h);
 field12 = new JTextField("0");//0  20
 content.add(field12);
 field12.setBounds(x + 2 * (w + cp), y, w, h);

 label = new JLabel("D: ");
 label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
 content.add(label);
 label.setBounds(x, y + (h + rp) * 1, w, h);
 field21 = new JTextField("0");
 content.add(field21);
 field21.setBounds(x + 1 * (w + cp), y + (h + rp) * 1, w, h);
 field22 = new JTextField("0");
 content.add(field22);
 field22.setBounds(x + 2 * (w + cp), y + (h + rp) * 1, w, h);

 label = new JLabel("V: ");
 label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
 content.add(label);
 label.setBounds(x, y + (h + rp) * 2, w, h);
 field31 = new JTextField("0");
 content.add(field31);
 field31.setBounds(x + 1 * (w + cp), y + (h + rp) * 2, w, h);
 field32 = new JTextField("0");
 content.add(field32);
 field32.setBounds(x + 2 * (w + cp), y + (h + rp) * 2, w, h);

 label = new JLabel("DayI: ");
 label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
 content.add(label);
 label.setBounds(x, y + (h + rp) * 3, w, h);
 field41 = new JTextField("30");
 content.add(field41);
 field41.setBounds(x + 1 * (w + cp), y + (h + rp) * 3, w, h);
 field42 = new JCheckBox("pf");
 field42.setSelected(true);
 content.add(field42);
 field42.setBounds(x + 2 * (w + cp), y + (h + rp) * 3, w, h);

 label = new JLabel("RefC: ");
 label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
 content.add(label);
 label.setBounds(x, y + (h + rp) * 4, w, h);
 field51 = new JTextField("150");
 content.add(field51);
 field51.setBounds(x + 1 * (w + cp), y + (h + rp) * 4, w, h);

 label = new JLabel("sbl/dt: ");
 label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
 content.add(label);
 label.setBounds(x, y + (h + rp) * 5, w, h);
 field61 = new JTextField("0");
 content.add(field61);
 field61.setBounds(x + 1 * (w + cp), y + (h + rp) * 5, w, h);
 field62 = new JTextField("0");
 content.add(field62);
 field62.setBounds(x + 2 * (w + cp), y + (h + rp) * 5, w, h);
 
 label = new JLabel("-/+: ");
 label.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
 content.add(label);
 label.setBounds(x, y + (h + rp) * 6, w, h);
 field71 = new JTextField("50");
 content.add(field71);
 field71.setBounds(x + 1 * (w + cp), y + (h + rp) * 6, w, h);
 field72 = new JTextField("50");
 content.add(field72);
 field72.setBounds(x + 2 * (w + cp), y + (h + rp) * 6, w, h);

 okButton = new JButton("OK");
 okButton.setBounds(x + 2 * (w + cp), y + (h + rp) * 7, w, h);
 content.add(okButton);
 okButton.setEnabled(false);
 okButton.addActionListener(new ActionListener() {
 public void actionPerformed(ActionEvent e) {
	 lab.checkData();
 }
 });
 
 cxButton = new JButton("CX");
 cxButton.setBounds(x + 1 * (w + cp), y + (h + rp) * 7, w, h);
 content.add(cxButton);
 cxButton.setEnabled(false);
 cxButton.addActionListener(new ActionListener() {
 public void actionPerformed(ActionEvent e) {
	 //lab_cndl.checkData();
	 float smbl=Float.parseFloat(field61.getText());
	 float date=Float.parseFloat(field62.getText());
	 stklHis_G_K k=new stklHis_G_K(instance);
	 float [][] data;
	 data=instance.queryK(smbl, date, Integer.parseInt(field71.getText()), Integer.parseInt(field72.getText()));
	 k.pv=data;
	 if(data==null)
		 return;
	 k.baseIdx=(int)date;
	 k.generate();
 }
 });
 
 status = new JLabel("");
 content.add(status);
 status.setBounds(x, y + (h + rp) * 8, w * 3, h);
 
 login.setBounds(x0, y0, width, height);
 login.setResizable(true);
 login.setVisible(true);
 login.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
				//lab.checkData();
			}
 });
 }

 public static void main(String[] args) {
 stklHis_G_LG gui = new stklHis_G_LG();
 stklHis_data in = new stklHis_data();
 gui.instance = in;
 in.gui = gui;
 gui.instance.loadData();
 gui.lab = new stklHis_lab_trnd(in);
 gui.lab_cndl = new stklHis_lab_cndl(in);

 }

 JTextField field11, field12, field21, field22, field31, field32, field41, field51, field61, field62, field71, field72;
 JCheckBox field42;
 JLabel status;
 JButton okButton,cxButton;
 stklHis_data instance = null;
 stklHis_lab_trnd lab = null;
 stklHis_lab_cndl lab_cndl = null;

}

