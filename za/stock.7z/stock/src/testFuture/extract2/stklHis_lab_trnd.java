package testFuture.extract2;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import testFuture.util;

public class stklHis_lab_trnd {

	boolean finished = false;

	LinkedBlockingQueue<float[]> resultQueue = new LinkedBlockingQueue<float[]>();

	stklHis_data dataclass;
	float[][][] data = null;
	stklHis_G_LG gui = null;
	public int dateback = 0;
	public int stocklist = 0;
	util util1 = new util();

	stklHis_lab_trnd(stklHis_data dataclass) {
		this.dataclass = dataclass;
		this.data = dataclass.data;
		this.gui = dataclass.gui;
		this.dateback = dataclass.dateback;
		this.stocklist = dataclass.stocklist;
	}

	public static void main(String[] args) {
		final stklHis_data s = new stklHis_data();
		final stklHis_lab_trnd d = new stklHis_lab_trnd(s);
		System.out.println(new java.util.Date());
		s.data();
		s.dateidx();
		System.out.println(new java.util.Date());

		new Thread() {
			public void run() {
				d.output(0);
			}
		}.start();
		d.gothrough();
		System.out.println(new java.util.Date());
	}

	public void output(int out) {
		int counta = 0;
		int countp = 0;
		int total = 0;
		List<Object[]> tmp = new LinkedList<Object[]>();
		while (true) {
			try {
				float[] rst = resultQueue.poll(1000, TimeUnit.MILLISECONDS);
				if (rst != null) {
					////// 0 smbl, 1 date, 2 trend, 3 avgv
					int s = (int) rst[0];
					int d = (int) rst[1];
					float open = 0;
					if ((d - 1 >= 0) && data[s][d - 1][5] > 0)
						open = data[s][d - 1][5];
					else{
						if (out == 0)
							System.out.println("\t" + data[s][d][0] + "\t" + data[s][d][1] + "\t trend:" + -rst[2]
									+ "\t avgv:" + (int) (rst[3] / 1000000) + "\t" + 0 + "|" + 0 + "\t"
									+ 0 + "|" + 0 + "\t" +0 + "|" + 0 + "\t r:" + 2);
						else if (out == 1) {
							Object item[] = { data[s][d][0], data[s][d][1], -rst[2], (int) (rst[3] / 1000000),
									0 + "|" + 0, 0 + "|" + 0,0 + "|" + 0, 2, "" };
							tmp.add(item);
							if (tmp.size() > 100) {
									}
							}
							continue;
						}
					int rng = 80;
					float p[] = new float[rng];
					for (int di = d - 1, i = 0; i < rng && di >= 0; di--, i++) {
						p[i] = data[s][di][2];
					}
					int[][][] r = util.tj_unit(open, p, true);
					if (out == 0)
						System.out.println("\t" + data[s][d][0] + "\t" + data[s][d][1] + "\t trend:" + -rst[2]
								+ "\t avgv:" + (int) (rst[3] / 1000000) + "\t" + r[1][1][0] + "|" + r[1][0][0] + "\t"
								+ r[2][1][0] + "|" + r[2][0][0] + "\t" + r[3][1][0] + "|" + r[3][0][0] + "\t r:"
								+ r[0][0][0]);
					else if (out == 1) {
						Object item[] = { data[s][d][0], data[s][d][1], -rst[2], (int) (rst[3] / 1000000),
								r[1][1][0] + "|" + r[1][0][0], r[2][1][0] + "|" + r[2][0][0],
								r[3][1][0] + "|" + r[3][0][0], r[0][0][0], "" };
						tmp.add(item);
						if (tmp.size() > 100) {
						}
					}
					total++;
					if (r[0][0][0] == 1)
						countp++;
					if (r[0][0][0] < 2)
						counta++;
				}
				if (finished && resultQueue.size() == 0)
					break;
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		}
		String summary = total + "\t" + counta + "\t" + countp;
		if (counta > 0)
			summary += ("\t" + countp * 100 / counta);
		if (out == 0) {
			System.out.println(summary);
		}
		if (out == 1) {
			/*
			 * int rt = 0; if (counta > 0) rt = countp * 100 / counta; Object
			 * item[] = { total ,counta ,countp,rt,"","","","", "" };
			 * tmp.add(item);
			 */
			Object[] s = (Object[]) tmp.toArray();
			Object[][] aa = new Object[s.length][];
			for (int i = 0; i < s.length; i++) {
				aa[i] = (Object[]) s[i];
			}
			stklHis_G_OUT list = new stklHis_G_OUT(aa, columnIdentifiers);
			list.dateIdxs = 1;
			list.instance = dataclass;
		}
	}

	public void gothrough() {
		// trend daterange dateinterval v
		finished = false;
		// Date dt1 = new Date();
		// Date dt2 = new Date();
		// System.out.println("utilCalPeakInUnit
		// cost:"+(dt2.getTime()-dt1.getTime()));

		float[] ref = new float[p1_refdaycnt];
		for (int i = 0; i < p1_refdaycnt; i++)
			ref[i] = i;

		for (int s = 0; s < stocklist; s++) {
			int preidxs = -1;
			int preidxd = -1;

			for (int d = dateback - p1_refdaycnt - 1; d >= 0; d--) {

				float[] cdata = new float[p1_refdaycnt];
				float maxp = 0;
				for (int j = 0; j < p1_refdaycnt; j++) {
					if (data[s][j][2] == 0)
						break;
					cdata[j] = data[s][d + j][2];
					if (data[s][d + j][2] > maxp)
						maxp = data[s][d + j][2];
				}

				if (cdata[p1_refdaycnt - 1] == 0)
					continue;

				if (maxp > data[s][d][2])
					continue;

				if (preidxs == s && preidxd - d < p1_dayp) {
					if (p1_pdayrefresh) {
						float trend = util1.PxyFloat(cdata, ref);
						if (trend < -p1_trendf && trend >= -p1_trendt) {
							preidxs = s;
							preidxd = d;
						}
					}
					continue;
				}
				// 0 symbol, 1 date, 2 CLOSEP,3 HIGH,4 LOW,5 OPENP, 6 volumn
				// data[s][d]

				float trend = util1.PxyFloat(cdata, ref);
				if (!(trend < -p1_trendf && trend >= -p1_trendt))
					continue;

				float sum = 0;
				int count = 0;
				for (int i = 0; i < p1_refdaycnt && cdata[i] > 0; i++) {
					count++;
					sum += data[s][d + i][6] * data[s][d + i][2];
				}
				int avgv = (int) ((sum / count) / 1000000);
				if (!(avgv >= p1_vf && avgv <= p1_vt))
					continue;
				double date = dataclass.getDDate(data[s][d][1]);
				if (!(date >= p1_datef && date <= p1_datet))
					continue;
				//////////////////////////////////////////////////////////////////////////////////////////

				float[] result = new float[5]; // 0 smbl, 1 date, 2 trend, 3
												// avgv
				result[0] = s;
				result[1] = d;
				result[2] = trend;
				result[3] = sum / count;// 0-(c2-c1)/body1;
				resultQueue.add(result);

				preidxs = s;
				preidxd = d;
			}
		}

		finished = true;
	}

	Object[] columnIdentifiers = new Object[] { "smbl", "dt", "trnd", "avgv", "15", "30", "30+", "r", "bt" };

	float p1_trendf = 85, p1_trendt = 100;
	double p1_datef = 0, p1_datet = 20491232;
	int p1_vf = 0, p1_vt = 999999999;
	int p1_dayp = 30;
	boolean p1_pdayrefresh = true;
	// trend daterange dateinterval v
	int p1_refdaycnt = 150;

	public void checkData() {
		finished = false;
		gui.status.setText("");
		try {
			p1_trendf = 85;
			p1_trendt = 100;
			p1_datef = 0;
			p1_datet = 20491232;
			p1_vf = 0;
			p1_vt = 999999999;
			p1_dayp = 30;
			p1_pdayrefresh = true;
			float f = Float.parseFloat("".equals(gui.field11.getText()) ? "0" : gui.field11.getText());
			if (f != 0)
				p1_trendf = f;
			f = Float.parseFloat("".equals(gui.field12.getText()) ? "0" : gui.field12.getText());
			if (f != 0)
				p1_trendt = f;
			f = Float.parseFloat("".equals(gui.field21.getText()) ? "0" : gui.field21.getText());
			if (f != 0)
				p1_datef = dataclass.getDDate(f);
			f = Float.parseFloat("".equals(gui.field22.getText()) ? "0" : gui.field22.getText());
			if (f != 0)
				p1_datet = dataclass.getDDate(f);
			int i = Integer.parseInt("".equals(gui.field31.getText()) ? "0" : gui.field31.getText());
			if (i != 0)
				p1_vf = i;
			i = Integer.parseInt("".equals(gui.field32.getText()) ? "0" : gui.field32.getText());
			if (i != 0)
				p1_vt = i;
			i = Integer.parseInt("".equals(gui.field41.getText()) ? "0" : gui.field41.getText());
			if (i != 0)
				p1_dayp = i;
			p1_pdayrefresh = gui.field42.isSelected();
			i = Integer.parseInt("".equals(gui.field51.getText()) ? "0" : gui.field51.getText());
			if (i != 0)
				p1_refdaycnt = i;
			i = Integer.parseInt("".equals(gui.field71.getText()) ? "0" : gui.field71.getText());
			if (i != 0)
				dataclass.p2_before = i;
			i = Integer.parseInt("".equals(gui.field72.getText()) ? "0" : gui.field72.getText());
			if (i != 0)
				dataclass.p2_after = i;

		} catch (Exception e) {
			gui.status.setText("error in p1");
			e.printStackTrace();
			return;
		}
		new Thread() {
			public void run() {
				output(1);
			}
		}.start();
		gothrough();
		System.out.println(new java.util.Date());
	}
}
