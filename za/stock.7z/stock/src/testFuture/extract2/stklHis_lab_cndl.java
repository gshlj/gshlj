package testFuture.extract2;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import testFuture.util;

public class stklHis_lab_cndl {
	 
	 boolean finished = false;

	 LinkedBlockingQueue<float[]> resultQueue = new LinkedBlockingQueue<float[]>();

	 stklHis_data dataclass;
	 float[][][] data = null;
	 stklHis_G_LG gui = null;
	 public int dateback = 0;
	 public int stocklist = 0;
	 util util1 = new util();
	 
	 stklHis_lab_cndl(stklHis_data dataclass){
	 this.dataclass = dataclass;
	 this.data = dataclass.data;
	 this.gui = dataclass.gui;
	 this.dateback = dataclass.dateback;
	 this.stocklist = dataclass.stocklist;
	 }
	 
	 public static void main(String[] args) {
	 final stklHis_data s = new stklHis_data();
	 final stklHis_lab_mormingStar d = new stklHis_lab_mormingStar(s);
	 System.out.println(new java.util.Date());
	 s.data();
	 s.dateidx();
	 System.out.println(new java.util.Date());

	 new Thread() {
	 public void run() {
	 d.output(0);
	 }
	 }.start();
	 d.gothrough();
	 System.out.println(new java.util.Date());
	 }

	 public void output(int out) {
	 int counta = 0;
	 int countp = 0;
	 int total = 0;
	 List<Object[]> tmp = new LinkedList<Object[]>();
	 while (true) {
	 try {
	 float[] rst = resultQueue.poll(1000, TimeUnit.MILLISECONDS);
	 if (rst != null) {
	 ////// 0 smbl, 1 date, 2 trend, 3 avgv
	 int s = (int) rst[0];
	 int d = (int) rst[1];
	 if (!(d - 1 >= 0))
	 continue;
	 float open = data[s][d - 1][5];
	 if (open == 0)
	 continue;
	 int rng = 80;
	 float p[] = new float[rng];
	 for (int di = d - 1, i = 0; i < rng && di >= 0; di--, i++) {
	 p[i] = data[s][di][2];
	 }
	 int[][][] r = util.tj_unit(open, p, true);
	 if (out == 0)
	 System.out.println("\t" + data[s][d][0] + "\t" + data[s][d][1] + "\t trend:" + -rst[2]
	 + "\t avgv:" + (int) (rst[3] / 1000000) + "\t" + r[1][1][0] + "|" + r[1][0][0] + "\t"
	 + r[2][1][0] + "|" + r[2][0][0] + "\t" + r[3][1][0] + "|" + r[3][0][0] + "\t r"
	 + r[0][0][0]);
	 else if (out == 1) {
	 Object item[] = new Object[rst.length+5];
	 item[0]=data[s][d][0];
	 item[1]=data[s][d][1];
	 item[item.length-5]=r[1][1][0] + "|" + r[1][0][0];
	 item[item.length-4]=r[2][1][0] + "|" + r[2][0][0] ;
	 item[item.length-3]=r[3][1][0] + "|" + r[3][0][0] ;
	 item[item.length-2]=r[0][0][0];
	 item[item.length-1]="";
	 for(int i = 2; i < rst.length ; i++)
	 item[i]=rst[i];
	 //{ data[s][d][0] , data[s][d][1] , -rst[2], (int) (rst[3] / 1000000) , r[1][1][0] + "|" + r[1][0][0] , r[2][1][0] + "|" + r[2][0][0] , r[3][1][0] + "|" + r[3][0][0] , r[0][0][0], "" };
	 tmp.add(item);
	 if (tmp.size() > 100) {
	 }
	 }
	 total++;
	 if (r[0][0][0] == 1)
	 countp++;
	 if (r[0][0][0] < 2)
	 counta++;
	 }
	 if (finished && resultQueue.size() == 0)
	 break;
	 } catch (Exception e1) {
	 e1.printStackTrace();
	 }
	 }
	 String summary = total + "\t" + counta + "\t" + countp;
	 if (counta > 0)
	 summary += ("\t" + countp * 100 / counta);
	 if (out == 0) {
	 System.out.println(summary);
	 }
	 if (out == 1) {
	 /*int rt = 0;
	 if (counta > 0)
	 rt = countp * 100 / counta;
	 Object item[] = { total ,counta ,countp,rt,"","","","", "" };
	 tmp.add(item);*/
	 Object[] s = (Object[]) tmp.toArray();
	 Object[][] aa = new Object[s.length][];
	 for (int i = 0; i < s.length; i++) {
	 aa[i] = (Object[]) s[i];
	 }
	 stklHis_G_OUT list = new stklHis_G_OUT(aa, columnIdentifiers);
	 list.dateIdxs = 1;
	 list.instance = dataclass;
	 }
	 }

		public void gothrough() {

			float[] ref = new float[refdaycnt];
			for (int i = 0; i < refdaycnt; i++)
				ref[i] = i;
			float[] ref2 = new float[refdaycnt2];
			for (int i = 0; i < refdaycnt2; i++)
				ref2[i] = i;

			for (int d = 0; d < dateback - refdaycnt; d++) {
				float[][] cdata = new float[stocklist][refdaycnt];
				float[][] cdata2 = new float[stocklist][refdaycnt2];
				float[] avgbody = new float[stocklist];
				for (int i = 0; i < stocklist; i++) {
					float sum = 0;
					for (int j = 0; j < refdaycnt; j++) {
						if (data[i][j][2] == 0)
							break;
						cdata[i][j] = data[i][d + j][2];
						if (j < refdaycnt2) {
							cdata2[i][j] = data[i][d + j][2];
							float tmp = data[i][d + j][2] - data[i][d + j][5];
							sum += tmp > 0 ? tmp : -tmp;
						}
					}
					avgbody[i] = sum / refdaycnt2;
				}
				for (int s = 0; s < stocklist; s++) {
					if (cdata[s][refdaycnt - 1] == 0)
						continue;
					// 0 symbol, 1 date, 2 CLOSEP,3 HIGH,4 LOW,5 OPENP, 6 volumn
					float ch1 = (data[s][d + 2][2] - data[s][d + 2][5]) * 100 / data[s][d + 2][5];
					float ch2 = (data[s][d + 1][2] - data[s][d + 1][5]) * 100 / data[s][d + 1][5];
					float ch3 = (data[s][d][2] - data[s][d][5]) * 100 / data[s][d][5];
					float gap1 = (data[s][d + 2][2] - data[s][d + 1][5]) * 100 / data[s][d + 1][5];
					float gap2 = (data[s][d][4] - data[s][d + 1][3]) * 100 / data[s][d + 1][5];

					float body1 = data[s][d + 2][2] - data[s][d + 2][5];
					float shadow1 = data[s][d + 2][3] - data[s][d + 2][4];
					float body2 = data[s][d + 1][2] - data[s][d + 1][5];
					float shadow2 = data[s][d + 1][3] - data[s][d + 1][4];
					float body3 = data[s][d][2] - data[s][d][5];
					float shadow_celling = data[s][d][3] - data[s][d][5];

					if (!(gap1 > -0.5))////// !!!!!!!
						continue;
					if (!(body1 < 0 && body3 > 0))
						continue;
					double PP_1len = -body1 / avgbody[s];
					/*
					 * if(!(0.2 < pp_1len))//////0.8 continue;
					 */
					double PP_3bvcshd = body3 / shadow_celling;////// !!!!!!!
					/*
					 * if(!(PP_3boat > 0.4))/////0.6 or more continue;
					 */
					if (!((ch2 < 0.2 || ch2 > -0.2) && (body1 / body2 > 3 || body1 / body2 < -3)))// star
						continue;

					if (!(data[s][d][2] > (data[s][d + 2][2] + data[s][d + 2][5]) / 2))/////// !!!!!!!
						continue;

					if (!(data[s][d + 2][6] < data[s][d + 1][6] && data[s][d + 1][6] < data[s][d][6]))
						continue;
					// f(3th long up shadow) smbl:300459.0 date:170412.0
					// f(3th long up shadow) smbl:300459.0 date:170509.0 !!strickly
					// a star? hesitate
					// 600718 80820 81110
					float min = 9999;
					for (int d1 = 0; d1 < refdaycnt2; d1++) {
						if (min > data[s][d + d1][2])
							min = data[s][d + d1][2];
					}
					if (data[s][d + 1][2] > min)
						continue;
					float PPtrend1 = util1.PxyFloat(cdata[s], ref);
					float PPtrend2 = util1.PxyFloat(cdata2[s], ref2);
					if (!(-PPtrend1 > 60))
						continue;

					float sum = 0;
					int count = 0;
					for (int i = 0; i < refdaycnt && data[s][d + i][6] > 0; i++) {
						count++;
						sum += data[s][d + i][6] * data[s][d + i][2];
					}
					int avgv = (int) ((sum / count) / 1000000);
					//////////////////////////////////////////////////////////////////////////////////////////

					float[] result = new float[7]; // 0 smbl, 1 date, 2 trend, 3 avgv
					result[0] = s;
					result[1] = d;
					result[2] = avgv;
					result[3] = -PPtrend1;
					result[4] = -PPtrend2;
					result[5] = (float) PP_1len;
					result[6] = (float) PP_3bvcshd;
					resultQueue.add(result);
					// data[s][d][0] , data[s][d][1] , -rst[2], (int) (rst[3] /
					// 1000000)
				}
			}

			finished = true;
		}
	 
	 Object[] columnIdentifiers = new Object[] {"smbl","dt","avgv","trend1","trend2","1len","3bvcshd","15","30","30+","r", "bt" };
	 
	 int refdaycnt =150;//edit
	 int refdaycnt2 =20;//edit

	 public void checkData() {
	 finished = false;
	 gui.status.setText("");
	 try {
	 float f = Float.parseFloat("".equals(gui.field11.getText()) ? "0" : gui.field11.getText());
	 if (f != 0)
	 refdaycnt = (int) f;
	 f = Float.parseFloat("".equals(gui.field12.getText()) ? "0" : gui.field12.getText());
	 if (f != 0)
	 refdaycnt2 = (int) f;
	 
	 } catch (Exception e) {
	 gui.status.setText("error in p1");
	 e.printStackTrace();
	 return;
	 }
	 new Thread() {
	 public void run() {
	 output(1);
	 }
	 }.start();
	 gothrough();
	 System.out.println(new java.util.Date());
	 }
}
