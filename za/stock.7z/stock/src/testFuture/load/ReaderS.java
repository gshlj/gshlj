package testFuture.load;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.util.HashSet;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import testFuture.util;

public class ReaderS implements Reader{

 Load loader;
 String startdt;
 String enddt;
 List<String> stockList = null;
 
 private Thread handler;
 //select * from Tbl_STK_PD where DATE = '2017-09-21'
 //2017-12-07
 public ReaderS(){
 handler = new Thread(){
 SocketAddress addr = new InetSocketAddress("192.193.171.150", 8080); 
 Proxy proxy = new Proxy(Proxy.Type.HTTP, addr); 
 public void run(){
 //http://q.stock.sohu.com/hisHq?code=cn_900952&start=20170230&end=20171122
 //http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol=sz300727&scale=60&ma=no&datalen=1000
 HashSet hs = new HashSet();
 for(int i = 0; i < stockList.size(); i++){
 String ss = stockList.get(i);
 String shortsmbl = ss.substring(3, 9);
 if(hs.contains(shortsmbl)){
 System.out.println("skipped :"+ ss);
 continue;
 }
 String s = "http://q.stock.sohu.com/hisHq?code=cn_"+shortsmbl+"&start="+startdt+"&end="+enddt;
 URL url;
 try {
 url = new URL(s);
 HttpURLConnection oConn = (HttpURLConnection) url.openConnection(proxy); 
 oConn.setConnectTimeout(5000); 
 oConn.connect(); 
 InputStream is = oConn.getInputStream();
 BufferedReader br = new BufferedReader(new InputStreamReader(is));
 String line = null;
 StringBuffer content = new StringBuffer("");
 while ((line = br.readLine( )) != null) {
 content.append(line);
 }
 JSONArray list = new JSONArray(content.toString( ));
 JSONObject obj = list.getJSONObject(0);
 int status = obj.getInt("status");
 if(status != 0)
 continue;
 hs.add(shortsmbl);
 list = obj.getJSONArray("hq");
 for(int j = list.length( ) - 1 ; j >= 0 ; j--){
 JSONArray l = list.getJSONArray( j ) ;
 priceEntity e = new priceEntity();
 e.symbol = shortsmbl;
 e.DATESTR = l.getString(0);
 e.CLOSE = Float.parseFloat(l.getString(2));
 e.HIGH = Float.parseFloat(l.getString(6));
 e.LOW = Float.parseFloat(l.getString(5));
 e.OPEN = Float.parseFloat(l.getString(1));
 e.VOLUM = Long.parseLong(l.getString(7)+"00");
 loader.messageQueue.put(e);
 }
 } catch (Exception e) {
 System.out.println(ss);
 continue;
 }
 if(i > 0 && i % 10 == 0)
 System.out.println("read :"+i);
 try {
 Thread.sleep(500);
 } catch (InterruptedException e) {
 e.printStackTrace();
 }
 }
 loader.finished = true;
 }
 };
 }
 //[{"status":0,"hq":[["2017-11-22","8.26","8.19","-0.02","-0.24%","8.13","8.31","114542","9398.52","0.60%"],["2017-11-21","8.18","8.21","0.09","1.1%","8.14","8.31","139661","11492.93","0.73%"],["2017-11-20","8.04","8.12","0.03","0.37%","7.88","8.14","147513","11755.87","0.77%"],["2017-11-17","8.33","8.09","-0.26","-3.11%","8.03","8.36","187341","15313.92","0.98%"],["2017-11-16","8.39","8.35","-0.03","-0.36%","8.33","8.41","109120","9131.10","0.57%"],["2017-11-15","8.40","8.38","-0.0S","-0.59%","8.37","8.50","105043","8845.85","0.55%"],["2017-11-14","8.56","8.43","-0.12","-1.40%","8.38","8.58","153127","12989.27","0.80%"],["2017-11-13","8.67","8.55","-0.16","-1.84%","8.51","8.75","188413","16179.60","0.98%"],["2017-11-10","8.66","8.71","0.00","0.00%","8.65","8.80","162619","14201.27","0.85%"],["2017-11-
 public void start() {
 handler.start();
 }

 public void setStartDt(String dt) {
 startdt = dt;
 }

 public void setEndDt(String dt) {
 enddt = dt;
 }

 public void setList(List<String> list) {
 stockList = list;
 }
 public void setLoad(Load load) {
 this.loader = load;
 }
 

}

