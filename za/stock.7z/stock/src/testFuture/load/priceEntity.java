package testFuture.load;

public class priceEntity {

 public int stkIdx;
 
 public String symbol;
 public int DATE;
 public long time;
 
 public float CLOSE;
 public float HIGH;
 public float LOW;
 public float OPEN;
 public long VOLUM; 
 
 public float ema12;
 public float ema26;
 public float diff;
 public float dea;
 public float macd;
 
 public int type;
 public String DATESTR;

}

