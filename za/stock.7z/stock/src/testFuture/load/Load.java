package testFuture.load;

import java.util.concurrent.LinkedBlockingQueue;

import testFuture.util;

public class Load {
 
 LinkedBlockingQueue<priceEntity> messageQueue = new LinkedBlockingQueue<priceEntity>();
 boolean finished = false;

 public static void main(String[] args) {
 System.out.println(new java.util.Date());
/* Load load = new Load();
 Reader reader = new ReaderSVIP();
 reader.setEndDt("20190309");
 reader.setLoad(load);
 Writer writer = new Writer();
 writer.loader = load;*/
 
 Load load = new Load();
 Reader reader = new ReaderSN();
 reader.setList(util.initStockList( ) );
 reader.setLoad(load);
 Writer writer = new Writer();
 writer.loader = load;
 
 //reader.setStartDt("20150101");
 //reader.setList(null);
 //reader.setList(util.initStockList( ) );
 //reader.setList(util.initStockListUS() );
 reader.start();
 writer.start();
 }
}

