package testFuture.load;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.util.HashSet;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import testFuture.util;

public class ReaderSVIP implements Reader{

 Load loader;
 String startdt;
 String enddt;
 List<String> stockList = null;
 
 private Thread handler;
 
	public ReaderSVIP() {
		handler = new Thread() {
			SocketAddress addr = new InetSocketAddress("192.193.171.150", 8080);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);

			public void run() {
				// http://q.stock.sohu.com/hisHq?code=cn_900952&start=20170230&end=20171122
				// http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol=sz300727&scale=60&ma=no&datalen=1000
				for (int i = 1; i < 100; i++) {
					String s = "http://vip.stock.finance.sina.com.cn/quotes_service/api/json_v2.php/Market_Center.getHQNodeData?page="
							+ i + "&num=100&sort=symbol&asc=1&node=hs_a&symbol=&_s_r_a=init";
					URL url;
					try {
						url = new URL(s);
						HttpURLConnection oConn = (HttpURLConnection) url.openConnection();
						oConn.setConnectTimeout(5000);
						oConn.connect();
						InputStream is = oConn.getInputStream();
						BufferedReader br = new BufferedReader(new InputStreamReader(is));
						String line = null;
						StringBuffer content = new StringBuffer("");
						while ((line = br.readLine()) != null) {
							content.append(line);
						}
						if ("null".equals(content.toString()))
							break;
						JSONArray list = new JSONArray(content.toString());
						int count = 0;
						for (int j = list.length() - 1; j >= 0; j--) {
							JSONObject o = list.getJSONObject(j);
							priceEntity e = new priceEntity();
							e.symbol = o.getString("symbol").substring(2, 8);
							e.DATESTR = enddt;
							e.CLOSE = Float.parseFloat(o.getString("trade"));
							e.HIGH = Float.parseFloat(o.getString("high"));
							e.LOW = Float.parseFloat(o.getString("low"));
							e.OPEN = Float.parseFloat(o.getString("open"));
							e.VOLUM = o.getLong("volume");
							if (e.OPEN > 0)
								loader.messageQueue.put(e);
							count++;
						}
						System.out.println(count);
					} catch (Exception e) {
						continue;
					}
					if (i > 0 && i % 10 == 0)
						System.out.println("read :" + i);
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				loader.finished = true;
			}
		};
	}
 public void start() {
 handler.start();
 }

 public void setStartDt(String dt) {
 startdt = dt;
 }

 public void setEndDt(String dt) {
 enddt = dt;
 }

 public void setList(List<String> list) {
 stockList = list;
 }
 public void setLoad(Load load) {
 this.loader = load;
 }
 

}

