package testFuture.load;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TimeZone;

import org.json.JSONArray;
import org.json.JSONObject;

import testFuture.util;

public class ReaderGUS implements Reader{

 Load loader;
 String startdt;
 String enddt;
 List<String> stockList = null;
 
 private Thread handler;
 public ReaderGUS(){
 handler = new Thread(){
 SocketAddress addr = new InetSocketAddress("192.193.171.150", 8080); 
 Proxy proxy = new Proxy(Proxy.Type.HTTP, addr); 
 public void run(){
 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd"); 
 dateFormat.setTimeZone(TimeZone.getTimeZone("America/New_York")); 
 List<priceEntity> list = new LinkedList<priceEntity>();
 
 for(int i = 0; i < stockList.size(); i++){
 String ss = stockList.get(i).trim();
 String q = ss.substring(1, ss.length());
 String x = "";
 if("1".equals(ss.substring(0, 1)))
 x = "NYSE";
 else if("2".equals(ss.substring(0, 1)))
 x = "NASDAQ";
 else if("3".equals(ss.substring(0, 1)))
 x = "OTCMKTS";
 else
 continue;
 String s = "http://finance.google.com/finance/getprices?q="+q+"&x="+x+"&i=86400&p=16Y&f=d,c,h,l,o,v";
 URL url;
 try {
 url = new URL(s);
 HttpURLConnection oConn = (HttpURLConnection) url.openConnection(proxy); 
 oConn.setConnectTimeout(5000); 
 oConn.connect(); 
 InputStream is = oConn.getInputStream();
 BufferedReader br = new BufferedReader(new InputStreamReader(is));
 String line = null;
 int count = 0;
 long a = 0;
 java.util.Date date = new java.util.Date();
 while ((line = br.readLine( )) != null) {

 //System.out.println(line);
 if(count < 7){
 count ++;
 continue;
 }
 String[] s1 = line.split(",");
 if(s1.length < 6)
 continue;
 priceEntity e = new priceEntity();
 long time;
 if(s1[0].startsWith("a")){
 long adate = Long.parseLong(s1[0].substring(1, s1[0].length())+"000");
 time = adate;
 a = adate;
 }else{
 time = Long.parseLong(s1[0])*86400000l+a;
 }
 date.setTime(time);
 e.symbol = ss;
 e.DATESTR = dateFormat.format(date);
 e.CLOSE = Float.parseFloat(s1[1]);
 e.HIGH = Float.parseFloat(s1[2]);
 e.LOW = Float.parseFloat(s1[3]);
 e.OPEN = Float.parseFloat(s1[4]);
 e.VOLUM = Long.parseLong(s1[5]);
 e.stkIdx = i;
 list.add(e);
 if(list.size() == 10000){
 loader.messageQueue.addAll(list);
 list = new LinkedList<priceEntity>( );
 }
 }
 } catch (Exception e) {
 System.out.println(ss);
 continue;
 }
 if(i > 0 && i % 10 == 0)
 System.out.println("read :"+i);
 try {
 Thread.sleep(2000);
 } catch (InterruptedException e) {
 e.printStackTrace();
 }
 }
 loader.messageQueue.addAll(list);
 loader.finished = true;
 }
 };
 }
 //[{day:"2009-10-30",open:"63.660",high:"91.800",low:"63.580",close:"70.810",volume:"29611564"},{day:"2009-11-02",open:"63.730",high:"67.260",low:"63.730",close:"63.730",volume:"8726860"},
 public void start() {
 handler.start();
 }

 public void setStartDt(String dt) {
 startdt = dt;
 }

 public void setEndDt(String dt) {
 enddt = dt;
 }

 public void setList(List<String> list) {
 stockList = list;
 }
 public void setLoad(Load load) {
 this.loader = load;
 }
 

}

