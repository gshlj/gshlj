package testFuture.load;

import java.sql.Connection;
import java.util.LinkedList;
import java.util.List;

import testFuture.util;

public class Writer {
 Load loader;
 private Thread handler;
 Connection conn = util.getConn();
 public Writer(){
 handler = new Thread(){
			public void run() {
				int count = 0;
				while (true) {
					if (loader.finished && loader.messageQueue.size() == 0)
						break;
					List<priceEntity> list = new LinkedList<priceEntity>();
					while (true) {
						if (list.size() == 10000 || (loader.finished && loader.messageQueue.size() == 0))//
							break;
						priceEntity p = loader.messageQueue.poll();
						if (p != null)
							list.add(p);
					}
					StringBuffer sql = new StringBuffer();
					for (priceEntity e : list) {
						if (e.symbol == null)
							continue;
						sql.append("insert into Tbl_STK_PD1 values('");
						sql.append(e.symbol);
						sql.append("','");
						sql.append(e.DATESTR);
						sql.append("',");
						sql.append(e.CLOSE);
						sql.append(",");
						sql.append(e.HIGH);
						sql.append(",");
						sql.append(e.LOW);
						sql.append(",");
						sql.append(e.OPEN);
						sql.append(",");
						sql.append(e.VOLUM);
						sql.append(");");
					}
					try {
						testFuture.util._operation(conn, sql.toString());
						System.out.println("write batch size:" + list.size());
					} catch (Exception e1) {
						e1.printStackTrace();
					}
					count++;
				}
				System.out.println("batch counts:" + count);
				System.out.println(new java.util.Date());
			}
 };
 }
 public void start() {
 handler.start();
 }
 public static void main(String[] args) {
 }
}

