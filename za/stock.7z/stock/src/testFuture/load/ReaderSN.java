package testFuture.load;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.util.HashSet;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import testFuture.util;

public class ReaderSN implements Reader {

	Load loader;
	String startdt;
	String enddt;
	List<String> stockList = null;

	private Thread handler;

	public ReaderSN() {
		handler = new Thread() {
			SocketAddress addr = new InetSocketAddress("192.193.171.150", 8080);
			Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);

			public void run() {
				for (int i = 0; i < stockList.size(); i++) {
					String ss = stockList.get(i);
					/*String shortsmbl = ss.substring(3, 9);
					String x = "sh";
					if ("SHE".equals(ss.substring(0, 3)))
						x = "sz";*/
					String shortsmbl = ss;
					String x = util.getX(ss);
					if ("SHE".equals(x))
						x = "sz";
					else
						x = "sh";
					String s = "http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol="
							+ x + shortsmbl + "&scale=240&ma=no&datalen=3000";
					URL url;
					try {
						url = new URL(s);
						HttpURLConnection oConn = (HttpURLConnection) url.openConnection();
						oConn.setConnectTimeout(5000);
						oConn.connect();
						InputStream is = oConn.getInputStream();
						BufferedReader br = new BufferedReader(new InputStreamReader(is));
						String line = null;
						StringBuffer content = new StringBuffer("");
						while ((line = br.readLine()) != null) {
							content.append(line);
						}
						JSONArray list = new JSONArray(content.toString());
						for (int j = 0; j < list.length(); j++) {
							JSONObject l = list.getJSONObject(j);
							priceEntity e = new priceEntity();
							e.symbol = shortsmbl;
							e.DATESTR = l.getString("day");
							e.CLOSE = Float.parseFloat(l.getString("close"));
							e.HIGH = Float.parseFloat(l.getString("high"));
							e.LOW = Float.parseFloat(l.getString("low"));
							e.OPEN = Float.parseFloat(l.getString("open"));
							e.VOLUM = Long.parseLong(l.getString("volume"));
							loader.messageQueue.put(e);
						}
					} catch (Exception e) {
						System.out.println(ss);
						continue;
					}
					if (i > 0 && i % 10 == 0)
						System.out.println("read :" + i);
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				loader.finished = true;
			}
		};
	}

	// [{day:"2009-10-30",open:"63.660",high:"91.800",low:"63.580",close:"70.810",volume:"29611564"},{day:"2009-11-02",open:"63.730",high:"67.260",low:"63.730",close:"63.730",volume:"8726860"},
	public void start() {
		handler.start();
	}

	public void setStartDt(String dt) {
		startdt = dt;
	}

	public void setEndDt(String dt) {
		enddt = dt;
	}

	public void setList(List<String> list) {
		stockList = list;
	}

	public void setLoad(Load load) {
		this.loader = load;
	}

}
