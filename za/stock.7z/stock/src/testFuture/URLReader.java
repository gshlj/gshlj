package testFuture;

import java.net.*;
import java.io.*;

public class URLReader {
 public static void main(String[] args) throws Exception {

 SocketAddress addr = new InetSocketAddress("192.193.171.150", 8080); 
 Proxy proxy = new Proxy(Proxy.Type.HTTP, addr); 
 HttpURLConnection oConn = null; 
 URL url;
 try { 
 //url = new URL("http://www.google.com/finance/getprices?q=603580&x=SHA&i=86400&p=20Y&f=d,chl,o,v");
	 // url = new URL("http://finance.google.com/finance/getprices?q=603389&x=SHA&i=60&p=10M&f=d,c,hl,o,v");
url = new URL("http://q.stock.sohu.com/hisHq?code=cn_900952&start=20170230&end=20171122");
 oConn = (HttpURLConnection) url.openConnection(); 
 oConn.setConnectTimeout(5000); 
 oConn.connect(); 
 InputStream is = oConn.getInputStream();
 BufferedReader in = new BufferedReader(
 new InputStreamReader(is));

 String inputLine;
 while ((inputLine = in.readLine()) != null)
 System.out.println(inputLine);
 in.close();
 
 } catch (Exception e) { 
 e.printStackTrace(); 
 } finally { 
 if (oConn != null) { 
 oConn.disconnect(); 
 } 
 } 
 }
}
