package Future;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import Future.load.priceEntity;

import java.util.Collections;
import java.util.HashMap;

public class importPrice {
	
	static List<String[]> stockList = util.initStockList();
	
	static LinkedList<priceEntity> priceList = new LinkedList<priceEntity>();
	
	static Connection conn = util.getConn();
//insert into dailyPriceraw values ('SHE','123456',20011111,11.91,12.19,11.84,12.19,42937186)
	public static int mode = 2; //0 all , n n days
	
	public static void main(String[] args) throws Exception {

		new Thread(){
			public void run(){
				java.util.Date date = new java.util.Date();
				int readCnt = 0;
				List<priceEntity> list = new LinkedList<priceEntity> ();
				String p = "20Y";
				String interval = "86400";
				if(mode > 0){
					p = mode+"d";
					interval = "86300";
				}
				Map<Integer, priceEntity> pm = new HashMap<Integer, priceEntity>();
				for(int i = 0; i< stockList.size()-1 ; i++){
					String[] ss = stockList.get(i);
					try {
						String s = "https://www.google.com/finance/getprices?q="+ss[1]+"&x="+ss[0]+"&i="+interval+"&p="+p+"&f=d,c,h,l,o,v";
						URL url = new URL(s);
						// URL url = new URL("http://localhost:8080/fileUpDownload/");  
						InputStream is = url.openStream();  
						BufferedReader br = new BufferedReader(new InputStreamReader(is, "gbk"));  
						String line = null; 
						int count = 0;
						long a = 0;
						while ((line = br.readLine()) != null) {
							if(count < 8){
								count++;
								continue;
							}
							String[] s1 = line.split(",");
							if(s1.length < 6)
								continue;
							priceEntity e = new priceEntity();
							long time;
							if(s1[0].startsWith("a")){
								long adate = Long.parseLong(s1[0].substring(1, s1[0].length())+"000");
								time = adate;
								a = adate;
							}else
								time = Long.parseLong(s1[0])*86400000l+a;
							date.setTime(time);
							e.DATE = util.getIntDate(date);
							//CLOSE,HIGH,LOW,OPEN,VOLUME
							e.CLOSE = Float.parseFloat(s1[1]);
							e.HIGH = Float.parseFloat(s1[2]);
							e.LOW = Float.parseFloat(s1[3]);
							e.OPEN = Float.parseFloat(s1[4]);
							e.VOLUM = Long.parseLong(s1[5]);
							e.stkIdx =  i;
							if(mode > 0){
								priceEntity pe = pm.get(e. DATE);
								if(pe == null)
									pm.put(e.DATE, e);
								else{
									pe.CLOSE = e.CLOSE;
									if(e.HIGH > pe.HIGH)
										pe.HIGH = e.HIGH;
									if(e. LOW < pe. LOW)
										pe.LOW = e.LOW;
									pe.VOLUM += e.VOLUM;
								}
								continue;
							}
							list.add(e);
							if(list.size() == 10000){
								while(listIO(true,list) == null){
									System.out.println("read sleeping");
									Thread.sleep(5000);
								}
								list = new LinkedList<priceEntity> ();
							}
						}
						if(mode > 0){
							for(priceEntity e: pm.values( )){
								e.VOLUM *= 2.2;
								list. add (e);
								if(list.size() == 10000){
								while(listIO(true,list) == null) {
										System.out.println("read sleeping");
										Thread.sleep(5000);
									}
									list = new LinkedList<priceEntity>( );
								}
							}
							pm= new HashMap<Integer,priceEntity>( );
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
					readCnt++;
					if(readCnt % 10 == 0)
						System.out.println("readCnt:"+readCnt);
					if(mode > 0){
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
				listIO(true,list);
				urlGetDailyPriceEnd = true;
			}
		}.start();
		
		new Thread(){
			public void run(){
				int batchCnt = 0;
				while(true){
					List<priceEntity> list = listIO(false,null);
					StringBuffer sql = new StringBuffer();
					if(list == null){
						System.out.println("batchCnt:"+batchCnt);
						return;
					}
					if(list.size() == 0)
						continue;
					for(priceEntity e : list){
						sql.append("insert into dailyPriceraw values ('");
						//11.91,12.19,11.84,12.19,42937186)
						String[] stk = stockList.get(e.stkIdx);
				    	sql.append(stk[0]);
				    	sql.append("','");
				    	sql.append(stk[1]);
				    	sql.append("',");
				    	sql.append(e.DATE);
				    	sql.append(",");sql.append(e.CLOSE);
				    	sql.append(",");
				    	sql.append(e.HIGH);
				    	sql.append(",");
				    	sql.append(e.LOW);
				    	sql.append(",");
				    	sql.append(e.OPEN);
				    	sql.append(",");
				    	sql.append(e.VOLUM);
				    	sql.append(");");
					}
					 try {
						util._operation(conn,sql.toString());
						batchCnt++;
						System.out.println("write batch size:"+list.size());
					} catch (Exception e1) {
						e1.printStackTrace();
					}
				}
			}
		}.start();
		
		System.out.println("priceList:"+priceList.size());
		//util.closeConn(conn);
	}
	
	synchronized static List<priceEntity> listIO(boolean in,List<priceEntity> e){
		if(in){
			if(priceList.size( ) == pipeSize)
				return null;
			else{
				listIn( e );
				return new LinkedList< priceEntity>( );
			}
			}
			else{
				List<priceEntity> list = listOut( );
				if(list == null && urlGetDailyPriceEnd)
					return null;
				else if(list == null){
					priceList = new LinkedList<priceEntity>( );
					point = 0;
					return new LinkedList<priceEntity>( );
				}
				else
					return list;
			}
	}
	
	private static void listIn(List<priceEntity> e){
		priceList.addAll(e);
	}
	
	static int pipeSize = 100000;
	
	static boolean urlGetDailyPriceEnd = false;
	static int point = 0;
	static int dbBatchSize = 5000;
	private static List<priceEntity> listOut(){
		int endIdx = 0;
		if((urlGetDailyPriceEnd || priceList.size()==pipeSize) && point == priceList.size()){
				return null;
		}
		else if(point+dbBatchSize<= priceList.size()){
			endIdx = point + dbBatchSize;
		}
		else if(point+dbBatchSize > priceList.size()&&(urlGetDailyPriceEnd || priceList.size()==pipeSize)){
			endIdx = priceList.size();//return size = 0 keep waiting
		}
		else
			endIdx = point;
		int size = endIdx - point;
		priceEntity [] entities = new priceEntity[size];
		List<priceEntity> result = new ArrayList<priceEntity>();
		int i = 0;
		int j = 0;
		for(priceEntity  e : priceList){
			if(point <= i && i < endIdx){
				i++;
				entities[j++] = e;
			}else{
				i++;
				continue;
			}
		}
		Collections.addAll(result, entities);
		//List result = priceList.subList(point, endIdx);
		point = endIdx;
		return result;
	}
	
}
