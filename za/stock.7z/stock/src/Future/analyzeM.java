package Future;

import java.sql.Connection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import Future.load.priceEntity;

public class analyzeM {

	static List<String> stockList = util.initStockList();
	static int baseDay = 20170520;//util.getIntDate(new Date());
	
	static short ema1d = 12;
	static short ema2d = 26;
	static short diffd = 9;
	static short backdays = 200;
	
	static float[][][] databack = new float[stockList.size()][6][backdays];
	//0        ,1        ,2        ,3       , 4        ,5
	//price  ,ema1, ema2,diff   , dea    ,bar,    
	static float[][] databack2 = new float[stockList.size()][4];
	//stkIdx  ,avgp20 , bar  , LCamt
	public static void main(String[] args) {
		
		initdata0();
		
		calc(ema1d,(short)1,(short)0);
		calc(ema2d,(short)2,(short)0);
		
		for(float[][] d1: databack){
			for(int i = 0; i< d1[0].length; i++){
				d1[3][i] = d1[1][i] - d1[2][i];
			}
		}
		
		calc(diffd,(short)4,(short)3);
		
		for(float[][] d1: databack){
			for(int i = 0; i< d1[0].length; i++){
				d1[5][i] = (d1[3][i] - d1[4][i])*2;
			}
		}
		
//cross strategy
		List<float[]> data2 = new LinkedList<float[]>();
		//what is wrong with below
		//for(int i = 0 ; i < databack.length && databack[i][5][0]>0 &&  databack[i][5][1]<0 ; i++){
		for(int i = 0; i < databack.length ; i++){
			if(! (databack[i][5][0]>0 &&  databack[i][5][1]<0))
				continue;
			float[] d = new float[4];
			d[0] = i;
			d[2] =  databack[i][5][0];
			data2.add(d);
			int pc = 0;
			float sump =0;
			for(int p = 0; p<20 ;p++ ){
				float prz =  databack[i][0][p];
				if(prz!=0){
					pc++;
					sump += prz;
				}
			}
			d[1]  = sump/pc;
			float sumb =0;
			for(int j=1 ; j< backdays ;j++){
				float b = databack[i][5][j];
				if(b>0)
					break;
				sumb += databack[i][5][j];
			}
			d[3] = sumb;
		}
		
		Collections.sort(data2, comparatorCross);
		for(float [] f: data2){
		int idx = (int)f[0];
		String sym = stockList.get(idx);
		/*System.out. println(sym[0]+sym[1]+" I"+f[1]+" I "+f[2]+" I "+f[3]+" I "+f[3]/f[1]);
		System.out. println(f[2]/f[1]+": : "+databack	[idx][5][0] +" I"+databack[idx][5][1] +" I"+databack[idx][5][2] +" I"+databack[idx] [5] [3] +" I"+databack[idx][5] [4] +" I"+databack[idx][5][5] +" I"+databack[idx] [5][6]+" I"+databack[idx][5][7]+" I"+databack[idx][5][8]+" I"+databack[idx][5][9]);
		System.out. println("*****cross strategy*****");*/
		}
//curve strategy
		System. out. println("****************************************");
		List<float[]> data3 = new LinkedList<float[]>();
		for(int i = 0; i < databack.length ; i++){
		if(!(databack[i][5][0]<0 && databack[i][5][0]/databack[i][0][0] >-0.002))
			continue;
		float[] d = new float[6];
		d[0] = i;
		d[2] = databack[i][5][0];
		int pc=0;
		float sump = 0;
		for(int p = 0; p<20 ;p++){
		float prz = databack[i][0][p];
		if(prz != 0){
		pc++;
		sump += prz;
		}
		}
		d[1] = sump/pc;
		int cntd = 0;
		for(int j=0; j< backdays; j++){
		float b = databack[i][5][j];
		if(b > 0)
		break;
		cntd++;
		}
		d[3] = cntd;
		int cntswich = 0;
		float IastPN = 0;
		for(int k = cntd-1 ;k>=1;k--){
		if(k > cntd-2){
		IastPN = databack[i][5][k];
		continue;
		}
		float PN = databack[i][5][k-1]-databack[i][5] [k];
		if(PN/IastPN < 0)
		cntswich ++;
		IastPN = PN;
		}
		d[5] = cntswich;
		d[4] = databack[i][5][0] - databack[i][5][3];
		if(cntswich == 1)
		data3.add(d);
		}
		Collections.sort(data3, comparatorCurve);
		for(float [] f : data3){
		int idx = (int)f[0];
		String sym = stockList.get(idx);
		System.out.println(sym+"IavgP:"+f[1]+"bar:"+f[2]+"days:"+f[3]+"incre3d:"+f[4]/f[1]+"swithcnt:"+f[5]);
		System.out.print("bars::");
		for(int c =0 ; c < 20; c++)
		System.out. print(databack[idx][5]	[c]+"I");
		System. out. println("");
		System.out. println("****curve strategy****");
		}
		util.closeConn(conn);
	}
	//static float[][] databack3 = new float[stockList.size()][6];
	//stkId   avgp20  bar  lcdays   inre3d   swithcnt
	
	public static void calc(short d,short tidx,short aidx){
		tw = (float) (2.0/(d+1));
		pw = (float) ((d-1.0)/(d+1));
		for(float[][] db : databack){
			calcema((short)0,db[tidx],db[aidx]);
		}
	}
	
	static float tw;//today weight
	static float pw;//previous day weight
	public static float  calcema(short cidx, float[] t, float[] p){
		float result = 0;
		if(cidx == p.length-1){
			result = p[cidx];
		}else{
			float presult = calcema((short) (cidx+1), t, p);
			result = tw* p[cidx] + pw * presult;
		}
		t[cidx] = result;
		return result;
	}
	
	public static Map<String,Integer> stockM = new HashMap<String,Integer>();
	public static void initdata0(){
		//select * from dailyPriceRaw where exchange = 'SHE' AND symbol =	'300027' and date <= 20170102 order by date desc limit 400;
		//select top 400 * from dailyPriceRaw where EXCHANGE = 'SHE' AND 	SYMBOL = '300391' and DATE <= '20170102' order by DATE desc
		//select EXCHANGE,SYMBOL,CLOSE from dailyPriceRaw where DATE between date_add('20170703',interval -500 day) and '20170703' order by EXCHANGE,SYMBOL,DATE DESC
		int sidx = 0;
		for(String stk : stockList){
			stockM.put(stk, sidx);
			sidx++;
		}

		StringBuffer sb= new StringBuffer("select EXCHANGE,SYMBOL,CLOSE from dailyPriceRaw where DATE between date_add('");
		sb. append (baseDay);
		sb.append("',interval -"+backdays+" day) and '");
		sb. append (baseDay);
		sb.append("' order by EXCHANGE,SYMBOL,DATE DESC");
		List<priceEntity> p = util.queryPrice(sb.toString(), conn);
		String psid = "";
		int idx = -1;
		int didx = 0;
		for(priceEntity e : p){
			String sid = e.exchange+e.symbol;
			if(psid.equals(sid)){
				databack[idx] [0] [didx++] = e.CLOSE;
			}
			else{
			if(stockM.get(sid) == null)
					continue;
				idx = stockM.get(sid);
				didx = 0 ;
				psid = sid ;
				databack[idx][0][didx++] = e.CLOSE;
			}
		}
	}
	
	
	static Connection conn = util.getConn();
	
	static Comparator comparatorCross = new Comparator(){
		public int compare(Object o1,Object o2){
			float[] r1 = (float[])o1;
			float[] r2 = (float[])o2;
			int result = new Float(r1[3]/r1[1]).compareTo(new Float(r2[3]/r2[1]));
			return result;
		}
	};
	
	static Comparator comparatorCurve = new Comparator() {
		public int compare(Object o1, Object o2) {
		float[] r1 = (float[])o1;
		float[] r2 = (float[])o2;
		int result = new Float(r2[3]+500*r2[4]/r2	[1]).compareTo(new Float(r1[3]+500*r1[4]/r1[1]));
		return result;
		}
	};
}
