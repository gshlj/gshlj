package Future;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.sql.*;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Date;

public class importPriceInfo {

	public static List<String[]> stockList = util.initStockList();
	public static int date = util.getIntDate(new Date());
	public static Connection conn = util.getConn();

	public static void main(String[] args) {
		String prefix = "http://www.google.com/finance/info?client=ig&q=";
		StringBuffer surl = new StringBuffer(prefix);
		for (int i = 0; i < stockList.size(); i++) {
			String[] s = stockList.get(i);
			surl.append(s[0]);
			surl.append(":");
			surl.append(s[1]);
			surl.append(",");
			if (i % 100 == 0 && i > 0) {
				JSONArray list = readURL(surl.toString());
				// JSONArray list =
				// readURL("http://finance.google.com/finance/info?client=ig&q=S[IA:603776");
				wirteDB(list);
				surl = new StringBuffer(prefix);
			}
		}
		util.closeConn(conn);
	}

	public static JSONArray readURL(String urlstr) {
		URL url;
		JSONArray list = null;
		try {
			url = new URL(urlstr.toString());
			// proxy
			/*
			 * SocketAddress addr = new InetSocketAddress("192.193.171.150",
			 * 8080); Proxy proxy = new Proxy(Proxy.Type.HTTP,addr);
			 */
			/*HttpURLConnection oConn = oConn = (HttpURLConnection) url.openConnection( proxy );
			oConn.setConnectTimeout(5000);
			oConn.connect();
			InputStream is = (InputStream) oConn.getContent();*/
			// InputStream is = url.openStream( );
			InputStream is = url.openStream();  
			BufferedReader br = new BufferedReader(new InputStreamReader(is));
			String line = null;
			StringBuffer content = new StringBuffer("");
			while ((line = br.readLine()) != null) {
				String l = line.replace("//", "{\"result\": {\"list\": ");
				content.append(l);
			}
			content.append(" }}");
			JSONObject obj = new JSONObject(content.toString()).getJSONObject("result");
			list = obj.getJSONArray("list");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	public static void wirteDB(JSONArray list) {
		if (list == null)
			return;
		try {
			StringBuffer sql = new StringBuffer("");
			for (int i = 0; i < list.length(); i++) {
				JSONObject jo = (JSONObject) list.get(i);
				String l = jo.getString("l").replace(",", "");
				if (l == null || l.trim().equals(""))
					continue;
				if (Float.parseFloat(l) == 0)
					continue;
				sql.append("insert into dailyPriceRaw values('");
				sql.append(jo.getString("e"));
				sql.append("','");
				sql.append(jo.getString("t"));
				sql.append("',");
				sql.append(date);
				sql.append(",");
				sql.append(l);
				sql.append(",");
				sql.append("0.0");
				sql.append(",");
				sql.append("0.0");
				sql.append(",");
				sql.append("0.0");
				sql.append(",");
				sql.append(0);
				sql.append(");");
			}
			//util._operation(conn, sql.toString());
			System.out.println(sql);
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
