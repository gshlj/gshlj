package Future.load;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class BBSJ {
	
	static int [] dt = {/*200703,200706,*/200709,200712,200803/*,200806,200809,200812,200903,200906,200909,200912,201003,201006,201009,201012,
			201103,201106,201109,201112,201203,201206,201209,201212,201303,201306,201309,201312,201403,201406,201409,201412,
			201503,201506,201509,201512,201603,201606,201609,201612,201703,201706,201709,201712,201803,201806,201809,201812,
			201903,201906*/};
	
	public static void main(String[] args) {
		//http://data.eastmoney.com/soft_new/bbsj/200703/yysj/sc/1.html
		String url = "http://data.eastmoney.com/soft_new/bbsj/";
		try {
		   
			
		    for(int d : dt){
		    	System.out.println(d);
		    	 BufferedWriter writer = new BufferedWriter(new FileWriter("D:\\gs\\Desktop\\STOCK\\bbsj\\"+d+".txt"));
		    	 for(int i =1 ; ; i++){
		    		// Thread.sleep(1000);
		    		 URL urI = new URL(url+d+"/yysj/sc/"+i+".html");
						// HttpURLConnection oConn = (HttpURLConnection)
						// urI.openConnection(proxy);
						HttpURLConnection oConn = (HttpURLConnection) urI.openConnection();
						oConn.setConnectTimeout(5000);
						oConn.connect();
						InputStream is = oConn.getInputStream();
						BufferedReader br = new BufferedReader(new InputStreamReader(is));
						String line = null;
						StringBuffer content = new StringBuffer("");
						while ((line = br.readLine()) != null) {
							content.append(line);
						}
						Document doc = Jsoup.parse(content.toString());
						//String title = doc.title();
						//System.out.println(title);
						Element tbody = doc.getElementById("dt_1").getElementsByTag("tbody").get(0);
						Elements trs = tbody.getElementsByTag("tr");
						if(trs.size() == 0)
							break;
						for(Element tr : trs){
							Elements td = tr.getElementsByTag("td");
							writer.write(td.get(0).text()+","+td.get(2).text().replace("-", "")+","+td.get(6).text().replace("-", "")+"\n");
						}
		    	 }
			    writer.close();
		    }
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
