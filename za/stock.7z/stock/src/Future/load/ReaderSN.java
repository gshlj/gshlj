package Future.load;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class ReaderSN implements Reader {

	Load loader;
	String startdt;
	String enddt;
	List<String> stocklist = null;
	private Thread handler;
//2017-12-07	3320
	public ReaderSN() {
		handler = new Thread() {
			/*
			 * SocketAddress addr = new InetSocketAddress("192.193.171,150",
			 * 8080); Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
			 */
			public void run() {
				//http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol=sz300727&scale=240&ma=no&datalen=3000
				for (int i = 0; i < stocklist.size(); i++) {
					String ss = stocklist.get(i);
					String shortsmbl = ss.substring(3, 9);
					String x="sh";
					if ("SHE".equals(ss.substring(0, 3)))
						x="sz";
					// String s = "http://qstock.sohu.com/hisHq?code=cn_+shortsm
					// bl+ &start= “+startdt+ “&end=" +enddt;
					String s = "http://money.finance.sina.com.cn/quotes_service/api/json_v2.php/CN_MarketData.getKLineData?symbol="+x+shortsmbl+"&scale=240&ma=no&datalen=6000";
					URL urI;
					try {
						urI = new URL(s);
						// HttpURLConnection oConn = (HttpURLConnection)
						// urI.openConnection(proxy);
						HttpURLConnection oConn = (HttpURLConnection) urI.openConnection();
						oConn.setConnectTimeout(5000);
						oConn.connect();
						InputStream is = oConn.getInputStream();
						BufferedReader br = new BufferedReader(new InputStreamReader(is));
						String line = null;
						StringBuffer content = new StringBuffer("");
						while ((line = br.readLine()) != null) {
							content.append(line);
						}
						JSONArray list = new JSONArray(content.toString());
						
						for (int j = 0 ; j < list.length() ; j ++) {
							JSONObject l = list.getJSONObject(j);
							priceEntity e = new priceEntity();
							e.symbol = shortsmbl;
							e.DATESTR = l.getString("day");
							e.CLOSE = Float.parseFloat(l.getString("close"));
							e.HIGH = Float.parseFloat(l.getString("high"));
							e.LOW = Float.parseFloat(l.getString("low"));
							e.OPEN = Float.parseFloat(l.getString("open"));
							e.VOLUM = Long.parseLong(l.getString("volume"));
							loader.messageQueue.put(e);
						}
					} catch (Exception e) {
						System.out.println(ss);
						continue;
					}
					if (i > 0 && i % 10 == 0)
						System.out.println("read :" + i);
					try {
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				loader.finished = true;
			}
		};
	}

	public void start() {
		handler.start();
	}

	public void setStartDt(String dt) {
		startdt = dt;
	}

	public void setEndDt(String dt) {
		enddt = dt;
	}

	public void setLoad(Load load) {
		this.loader = load;
	}

	public void setlist(List<String> list) {
		stocklist = list;
	}

}
