package Future.load;

import java.util.List;

public interface Reader {
	
	void start( );
	void setStartDt(String dt);
	void setEndDt(String dt);
	void setlist(List<String> list);
	void setLoad(Load load);
}
