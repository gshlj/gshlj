package Future.load;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

import Future.util;

public class Load {

	LinkedBlockingQueue< priceEntity> messageQueue = new LinkedBlockingQueue< priceEntity>();
	boolean finished = false;
	public static void main(String[] args) {
	System.out.println(new java.util.Date());
	Load load = new Load();
	//ReaderS reader = new ReaderS();
	//Reader reader = new ReaderSVIP();
	ReaderSN reader = new ReaderSN();
	reader.setLoad (load);
	Writer writer = new Writer( ) ;
	writer.loader = load;
	/*reader.setStartDt("20150101");
	reader.setEndDt("20171215");
	reader.setlist( util.initStockList());*/
	List<String> stockList = new ArrayList<String>();
	stockList.add("SHA000001");
	stockList.add("SHE399001");
	stockList.add("SHE399006");
	reader.setlist(stockList);
	reader.start();
	writer.start();

}
	}
