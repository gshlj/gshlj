package Future.load;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.URL;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

public class ReaderS implements Reader {

	Load loader;
	String startdt;
	String enddt;
	List<String> stocklist = null;
	private Thread handler;
//2017-12-07	3320
	public ReaderS() {
		handler = new Thread() {
			/*
			 * SocketAddress addr = new InetSocketAddress("192.193.171,150",
			 * 8080); Proxy proxy = new Proxy(Proxy.Type.HTTP, addr);
			 */
			public void run() {
				// http://q.stock.sohu.com/hisHq?code= cn_900952&sta rt=
				// 20170230&end = 20171122
				// http://m oney.fi na nce.si na.com cf/quotes_service/a
				// pi/json_v2. php/CNMa rketData.getKLi neData?sym bol=
				// sz300727&scale=60&ma= no&datalen= 1000
				java.util.HashSet hs = new java.util.HashSet();
				for (int i = 0; i < stocklist.size(); i++) {
					String ss = stocklist.get(i);
					String shortsmbl = ss.substring(3, 9);
					if (hs.contains(shortsmbl)) {
						System.out.println("skipped :" + ss);
						continue;
					}
					// String s = "http://qstock.sohu.com/hisHq?code=cn_+shortsm
					// bl+ &start= “+startdt+ “&end=" +enddt;
					String s = "http://q.stock.sohu.com/hisHq?code=cn_" + shortsmbl + "&start=" + startdt + "&end="
							+ enddt;
					URL urI;
					try {
						urI = new URL(s);
						// HttpURLConnection oConn = (HttpURLConnection)
						// urI.openConnection(proxy);
						HttpURLConnection oConn = (HttpURLConnection) urI.openConnection();
						oConn.setConnectTimeout(5000);
						oConn.connect();
						InputStream is = oConn.getInputStream();
						BufferedReader br = new BufferedReader(new InputStreamReader(is));
						String line = null;
						StringBuffer content = new StringBuffer("");
						while ((line = br.readLine()) != null) {
							content.append(line);
						}
						JSONArray list = new JSONArray(content.toString());
						JSONObject obj = list.getJSONObject(0);
						int status = obj.getInt("status");
						if (status != 0)
							continue;
						hs.add(shortsmbl);
						list = obj.getJSONArray("hq");
						for (int j = list.length() - 1; j >= 0; j--) {
							JSONArray l = list.getJSONArray(j);
							priceEntity e = new priceEntity();
							e.symbol = shortsmbl;
							e.DATESTR = l.getString(0);
							e.CLOSE = Float.parseFloat(l.getString(2));
							e.HIGH = Float.parseFloat(l.getString(6));
							e.LOW = Float.parseFloat(l.getString(5));
							e.OPEN = Float.parseFloat(l.getString(1));
							e.VOLUM = Long.parseLong(l.getString(7) + "00");
							loader.messageQueue.put(e);
						}
					} catch (Exception e) {
						System.out.println(ss);
						continue;
					}
					if (i > 0 && i % 10 == 0)
						System.out.println("read :" + i);
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				loader.finished = true;
			}
		};
	}

	public void start() {
		handler.start();
	}

	public void setStartDt(String dt) {
		startdt = dt;
	}

	public void setEndDt(String dt) {
		enddt = dt;
	}

	public void setLoad(Load load) {
		this.loader = load;
	}

	public void setlist(List<String> list) {
		stocklist = list;
	}

}
