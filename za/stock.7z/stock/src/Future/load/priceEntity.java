package Future.load;

public class priceEntity {

	public int stkIdx;
	
	public String exchange;
	public String symbol;
	public int DATE;
	public float CLOSE;
	public float HIGH;
	public float LOW;
	public float OPEN;
	public long VOLUM;
	
	public float ema12;
	public float ema26;
	public float diff;
	public float dea;
	public float macd;
	
	public String DATESTR;

}
