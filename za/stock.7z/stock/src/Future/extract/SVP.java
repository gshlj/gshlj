package Future.extract;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import Future.util;
import Future.load.priceEntity;

public class SVP {
	public List<String> stocklist = util.initStockList();
	float[][][] data = new float[stocklist.size()][200][7];
	// 0 symbol 1 date, 2 CLOSEP,3 HIGH,4 LOW,5 OPENP, 6 volumn
	float tdata[][] = null;
	String tsym = "300110";
	String tdtend = "20171208";
	String tdtstart = "";
	int tdtlen = 30;
	Connection conn = util.getConn();

	/*
	 * select CQNVERT(float,SYMBCL),substring(convert(char(8),DATE,112)3,8),
	 * CLCSEP,HIGH,LCW,OPENP,convert(float,VOLUM) FRQM Tbl_STK_PD1 where DATE
	 * between '20171207' and '20171208'
	 */
	public static void main(String[] args) {
		System.out.println(new java.util.Date());
		SVP s = new SVP();
		System.out.println(new java.util.Date());
		s.data();
		System.out.println(new java.util.Date());
		s.tdata();
	}

	public void data() {
		try {
			// System.out.println("queryPricea:"+new Date());
			Statement statement = conn.createStatement();
			// statement.setFetchSize(100000);
			StringBuffer sb = new StringBuffer(
					"select	CONVERT(floatSYMBOL),substring(convert(char(8),DATE112),3,8),CLOSEP,HIGH,LOW,OPENP,convert(floatVOLUM)	FROM	Tbl_STK_PD1	where	DATE	between	'20170607'	and	'20171208'	order	by	SYMBOL,DATE");
			ResultSet rs = statement.executeQuery(sb.toString());// rs.getFetchSize()
			float sm = 0, dt = 0;
			int ism = -1, idt = 0;
			while (rs.next()) {
				float esm = rs.getFloat(1);
				if (esm != sm) {
					ism++;
					sm = esm;
					idt = 0;
				}
				data[ism][idt][0] = esm;
				data[ism][idt][1] = rs.getFloat(2);
				data[ism][idt][2] = rs.getFloat(3);
				data[ism][idt][3] = rs.getFloat(4);
				data[ism][idt][4] = rs.getFloat(5);
				data[ism][idt][5] = rs.getFloat(6);
				data[ism][idt++][6] = rs.getFloat(7);
			}
			rs.close();
			statement.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void tdata() {
		StringBuffer sb = new StringBuffer("select	*	from	Tbl_STK_PD1	where	DATE	between	");
		if (tdtstart != null && tdtstart.length() > 0) {
			sb.append("'");
			sb.append(tdtstart);
			sb.append("'");
		} else {
			sb.append("dateadd(dd,-");
			sb.append(tdtlen);
			sb.append(",'");
			sb.append(tdtend);
			sb.append("')");
		}
		sb.append("	and	'");
		sb.append(tdtend);
		sb.append("'");
		sb.append("	and	SYMBOL	='");
		sb.append(tsym);
		sb.append("'");
		sb.append("	order	by	DATE");
		List<priceEntity> p = util.queryPrice(sb.toString(), conn);
		tdata = new float[p.size()][7];
		for (int i = 0; i < p.size(); i++) {
			// 0 symbol, 1 date, 2 CLOSEP,3 HIGH,4 LOW,5 OPENP, 6 volumn
			tdata[i][0] = Float.parseFloat(p.get(i).symbol);
			tdata[i][1] = p.get(i).DATE % 1000000;
			tdata[i][2] = p.get(i).CLOSE;
			tdata[i][3] = p.get(i).HIGH;
			tdata[i][4] = p.get(i).LOW;
			tdata[i][5] = p.get(i).OPEN;
			tdata[i][6] = p.get(i).VOLUM;
		}
	}
}
