package Future;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import Future.load.priceEntity;

public class util {
	
    public static void _operation(Connection conn, String sql) throws Exception{
        Statement curStmt = null;
        try {
            curStmt = conn.createStatement();
            conn.setAutoCommit(false);
            /*curStmt.executeUpdate(sql);*/
            String[] ss = sql.split(";");
            for(String s : ss){
            	curStmt.addBatch(s);
            }
            curStmt.executeBatch();  
            conn.commit();  
            // 清空stmt中积攒的sql  
            curStmt.clearBatch();
            conn.setAutoCommit(true);
        } catch (Exception e) {
            throw e;
        } finally {
        	curStmt.close();
        }
    }

	public static Connection getConn(){
		String driver = "com.mysql.jdbc.Driver";
		String url = "jdbc:mysql://localhost:3306/market?useUnicode=true&characterEncoding=utf8&serverTimezone=GMT%2B8&useSSL=false";
		String user = "root";
		String password = "gshlj1986";
		Connection conn = null;
		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			System.out.println("error in connecting db!");
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void closeConn(Connection conn){
		try {
			conn.close();
		} catch (Exception e) {
			System.out.println("error in closing db!");
			e.printStackTrace();
		}
	}
	
/*	public static List<String[]> initStockList(){
		List<String[]> stockList = new ArrayList<String[]>();
		try {
			Connection conn =  getConn();
			Statement statement = conn.createStatement();
			String sql = "select * from stocks ";
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				String [] s = new String [2];
				s[0] = rs.getString("exchange");
				s[1] = rs.getString("symbol");
				stockList.add(s);
			}
			rs.close();
			statement.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return stockList;
	}*/
	
	public static List<String> initStockList(){
		List<String> stockList = new ArrayList<String>();
		try {
			Connection conn =  getConn();
			Statement statement = conn.createStatement();
			String sql = "select * from Tbl_STK_L ";
			//String sql = "select distinct symbol from Tbl_STK_PD1";
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				stockList.add(rs.getString(1));
			}
			rs.close();
			statement.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return stockList;
	}
	
	static SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
	public static int getIntDate(Date date){
		return Integer.parseInt(sdf.format(date));
	}
	
	public static List<priceEntity> queryPrice(String sql, Connection conn){
		List<priceEntity> stockList = new LinkedList<priceEntity>();
		try {
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while (rs.next()) {
				priceEntity s = new priceEntity();
				s.exchange = rs.getString("exchange");
				s.symbol = rs.getString("symbol");
				/*ss.DATE = rs.getInt("DATE");*/
				s.CLOSE = rs.getFloat("CLOSE");
				/*s.HIGH = rs.getFloat("HIGH");
				s.LOW = rs.getFloat("LOW");
				s.OPEN = rs.getFloat("OPEN");
				s.VOLUM = rs.getLong("VOLUM");*/
				stockList.add(s);
			}
			rs.close();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return stockList;
	}
	
}
