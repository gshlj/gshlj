package Future;

import java.awt.Robot;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class CLKDaemon {

	public static void main(String[] args) {
		try {
			int xCoord = 200;
			while (true) {
				Calendar calendar = new GregorianCalendar();
				int hour = calendar.get(Calendar.HOUR_OF_DAY);
				int min = calendar.get(Calendar.MINUTE);
				if ((hour == 18 && min >= 55) || hour > 18)
					//break;
					System.out.println("break");
				if (xCoord > 1000){
					xCoord = 200;
					
				}
					
				xCoord += 50;
				int yCoord = 100;
				System.out.println(xCoord);
				// Move the cursor
				Robot robot = new Robot();
				robot.mouseMove(xCoord, yCoord);
				Thread.sleep(200000);
			}
			// These coordinates are screen coordinates
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}
